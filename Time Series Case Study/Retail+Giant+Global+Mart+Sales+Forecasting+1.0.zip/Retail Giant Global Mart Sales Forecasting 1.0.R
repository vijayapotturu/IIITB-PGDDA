###############################################
#############Global Mart Case Study ###########
###############################################

################################################################
#Business Understanding
#Data Understanding
#Data Preparation & EDA
#Model Building 
#Model Evaluation
################################################################

### Business Understanding:
# Global Mart is an online store super giant having worldwide operations. It takes
# orders and delivers across the globe and deals with all the major product
# 3 Segments - consumer, corporate & home office across 7 Markets - US,APAC, EU, Africa, EMEA, LATAM,Canada

### Aim:
# The aim is to finalise the plan for the next 6 months.  
# Forecast the sales and the demand for the next 6 months, that would help manage
# the revenue and inventory accordingly 7 different market segments and in 3 major categories. 
# Forecast at the granular level, to do so, subset the data into 21 (7*3) buckets for analysis. 
# But not all of these 21 market buckets are important from the store's point of view. 
# So find out 2 most profitable (and consistent) segment from these 21 
# and forecast the sales and demand for these segments.

######################################################################################
# Getting ready for analysis and Loading the data                                    #                     
######################################################################################
### Install required packages
library(tidyverse)
library(tseries)
library(forecast)
library(ggplot2)
library(ggthemes)
library(dplyr)

# Clear environment variables.
rm(list=ls())

# Load transaction level data to dataframe.
transactions <- read.csv("Global Superstore.csv", stringsAsFactors = FALSE, header = TRUE)


#####################################################################################
# EDA of data.                                                                      #
#####################################################################################

str(transactions)
# 51290 observations of 24 variables.
# There are 17 character variable and 7 continious variable

#Check if Row.ID are duplicated
anyDuplicated(transactions$Row.ID) # There are no duplicate Row.ID

# Confirm that Order.ID values are all unique
length(unique(transactions[, 2]))
# Only 25035 unique Order.IDs but 51290 rows in total.

# Compare some rows with duplicate Order.ID to investigate this.
duplicates <- transactions[duplicated(transactions$Order.ID) | 
               duplicated(transactions$Order.ID, fromLast = TRUE),]

duplicates <- duplicates[order(duplicates$Order.ID), ]
head(duplicates)
# Rows can have a duplicate Order.ID but different Product.ID for each row. So Row.ID
# should be the true unique/primary key variable. 

#Check this.
length(unique(transactions[, 1])) # 51290, every row has unique Row.ID

# Check for NA values.
sum(is.na(transactions))                                      # 41296 NA values.

#Check which column has NA values
colSums(is.na(transactions))  # 41296 NA values all are in Postal Code.

which(unlist(lapply(transactions, function(x) any(is.na(x)))))
# There are only NA values in the Postal.Code column. But in fact as we are building
# a time series model, this will not impact the model so leave them as NA.

# Check for blank values.
sum(sapply(transactions, function(x) length(which(x == "")))) # No blank values.

# Check if column has same value repeated for all the rows
vapply(transactions, function(x) length(unique(x)) > 1, logical(1L)) 
# As output of this is TRUE for all columns that indicates all columns contain more
# than 1 unique values. So no need to remove any column at this stage of analysis

#View(unique(transactions$Market)) # There are 7 unique values - US,APAC, EU, Africa, EMEA, LATAM,Canada
#View(unique(transactions$Segment)) # Has got 3 unique values - Consumer, Corporate, Home Office

#####################################################################################
# Data preparation                                                                  #
#####################################################################################

# Convert Order.Date and Ship.Date to date type.
transactions$Order.Date <- as.Date(transactions$Order.Date, format = "%d-%m-%Y")
transactions$Ship.Date <- as.Date(transactions$Ship.Date, format = "%d-%m-%Y")

#Checking Order Dates duration
summary(transactions$Order.Date)
# data from Jan 2011 to Dec 2014 (48 months)

# For the timeseries we will need to aggregate by month, so create a new column with
# month. Use "%Y %m" format and then arrange it in chronological order.
transactions$Order.Month <- format(transactions$Order.Date, format="%Y %m")
transactions <- transactions[with(transactions,order(Order.Month)),]

# Add sequence number of months (from 1 for January 2011 to 48 for December 2014).
month_lookup <- as.data.frame(levels(as.factor(transactions$Order.Month)))
colnames(month_lookup) <- c("Months")
month_lookup$Year <- substr(month_lookup$Months,1,4)
month_lookup$month <- substr(month_lookup$Months,6,7)
month_lookup <- month_lookup[with(month_lookup,order(Year,month)),]
month_lookup$TS <- seq(1:48)

# Add the sequence number back to the transactions dataframe.
month_lookup <- subset(month_lookup, select = c(Months, TS))
transactions <- merge.data.frame(transactions, month_lookup, 
                                 by.x = "Order.Month",
                                 by.y = "Months", all.x = TRUE)

# We need to find the 2 most profitable and consistently profitable segments.
# Segment the whole dataset into the 21 combinations of Market and customer.
# Segment and aggregate monthly Profit, Sales and Quantity for each segment.
segmented.monthly <- group_by(transactions, Segment, Market, TS)
aggregated.monthly <- summarize(segmented.monthly, Monthly.Profit = sum(Profit),
                                Monthly.Sales = sum(Sales),
                                Monthly.Quantity = sum(Quantity))

# Now we have monthly values for each segment, we can calculate Mean and Coefficient
# of Variation of the monthly profits.
segmented.total <- group_by(aggregated.monthly, Segment, Market)
aggregated.total <- summarize(aggregated.monthly,
                                Total.Profit = sum(Monthly.Profit),
                                Total.Sales = sum(Monthly.Sales),
                                Total.Quantity = sum(Monthly.Quantity),
                                Std.Dev.Profit = sd(Monthly.Profit, na.rm = TRUE),
                                Mean.Profit = mean(Monthly.Profit, na.rm = TRUE),
                                Coef.of.Var = Std.Dev.Profit / Mean.Profit * 100)

# Identify the two segments with the highest total profits.
head(aggregated.total[order(-aggregated.total$Total.Profit), ], 2)

# SEGMENT                 TOTAL PROFIT
# Consumer APAC           222,818
# Consumer EU             188,688

# Identify the two segments with the most consistent monthly profit, i.e. the lowest
# coefficient of variance.
head(aggregated.total[order(aggregated.total$Coef.of.Var), ], 2)

#     SEGMENT             COEFFICIENT OF VARIANCE
#  1  Consumer EU         62.4
#  2  Consumer APAC       63.2

# The best two segments are Consumer EU and Consumer APAC, both the total profits and
# coefficient of variance

# Graphs to visualise Profit and Coefficient of Variance by market segment.
ggplot(aggregated.total, aes(x = reorder(Market,-Total.Profit), y = Total.Profit,fill=Segment)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(x = "Market", y = "Total Profit", title = "Total Profit Vs. Market Segment") +
  theme_pander()+
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="bottom")

ggplot(aggregated.total, aes(x = reorder(Market,Coef.of.Var), y = Coef.of.Var,fill=Segment)) + 
  geom_bar(stat = "identity", position = "dodge") +
  labs(x = "Market", y = "Coefficient of Variance", title = "Coefficient of Variance Vs. Market Segment") +
  theme_pander() +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="bottom")

#####################################################################################
# Model Building                                                                    #
#####################################################################################

# After identifying the 2 most profitable segments, the next challenge is to forecast
# the sales and quantity for the next 6 months. We need Sales and Quantity timeseries
# and to separate the last 6 months of data to use for model evaluation later.
# Consumer EU and Consumer APAC timeseries both have 48 months of data. Use 42 months
# to create the model and 6 months for evaluation.

############################## EU Consumer Sales ####################################
Consumer.EU <- filter(aggregated.monthly, Segment == "Consumer" & Market == "EU")
totalts.build.EU.Sales <- ts(Consumer.EU$Monthly.Sales,frequency = 12, start = c(2011, 1))
plot(totalts.build.EU.Sales,main = "Sales for EU Consumer from 2011 to 2014",xlab="Time",ylab="Sales")

#Let us begin to understand the individual components of our Sales Time Series
ts.build.EU.Sales.decompose <- decompose(totalts.build.EU.Sales)
plot(ts.build.EU.Sales.decompose, col = "blue")
## A linearly increasing trend with a positive slope and A low amplitude sinusoidal seasonality.

build.EU <- Consumer.EU[1:42, ]           # Build model from first 42 months' data.
outdata <- Consumer.EU[43:48, ]           # Test model from 43 to 48 months data

# Create and visualise timeseries of monthly sales
ts.build.EU.Sales <- ts(build.EU$Monthly.Sales, frequency = 12, start = c(2011, 1))
# Plot the time series of EU Sales to get an understanding of its pattern.
plot(ts.build.EU.Sales,main = "Sales for EU Consumer",xlab="Time",ylab="Sales")
# Shows an upward trend and some seasonality.

# Testing Holt winters at various alpha values for smoothing timeseries.
cols <- c("red", "blue", "green", "black")
alphas <- c(0.2, 0.4, 0.6)    # Chosen by trial and error method
labels <- c(paste("alpha =", alphas))
for (i in seq(1,length(alphas))) {
  smoothedseries <- HoltWinters(ts.build.EU.Sales, alpha = alphas[i], beta = FALSE,
                                gamma=FALSE)
  lines(fitted(smoothedseries)[,1], col=cols[i], lwd=2)
}
legend("topleft", labels, col=cols, lwd=2)
smoothedseries <- HoltWinters(ts.build.EU.Sales, alpha = 0.4, beta = FALSE,
                              gamma = FALSE)  # Choose alpha = 0.4

# Compare this to moving average smoothing
w <- 1    # Chosen by trial and error method to get best smoothing.
EU.Sales.smoothedseries <- stats::filter(ts.build.EU.Sales, 
                         filter = rep(1 / ( 2 * w + 1), (2 * w + 1)), 
                         method = "convolution", sides = 2)

# Smoothing left end of the time series
diff <- EU.Sales.smoothedseries[w + 2] - EU.Sales.smoothedseries[w + 1]
for (i in seq(w, 1, -1)) {
  EU.Sales.smoothedseries[i] <- EU.Sales.smoothedseries[i + 1] - diff
}

# Smoothing right end of the time series
n <- length(ts.build.EU.Sales)
diff <- EU.Sales.smoothedseries[n - w] - EU.Sales.smoothedseries[n - w - 1]
for (i in seq(n - w + 1, n)) {
  EU.Sales.smoothedseries[i] <- EU.Sales.smoothedseries[i - 1] + diff
}

# Plot both the moving average and Holt Winters smoothed timeseries.
timevals_in <- build.EU$TS
plot(ts.build.EU.Sales,main = "Sales for EU Consumer with Moving Average & HoltWinter",xlab="Time",ylab="Sales")
lines(EU.Sales.smoothedseries, col = "blue", lwd = 2)     # Moving average
lines(fitted(smoothedseries)[, 1], col = "red", lwd = 2)  # Holt Winters

# Proceed using the moving average smoothed timeseries, to build a model by classical
# decomposition. First convert the time series to a dataframe.
EU.Sales.smootheddf <- as.data.frame(cbind(timevals_in,
                                           as.vector(EU.Sales.smoothedseries)))
colnames(EU.Sales.smootheddf) <- c('Month', 'Sales')

# Now, let's fit a multiplicative model with trend and seasonality to the data
# Seasonality will be modeled using a sinusoid function
lmfit <- lm(Sales ~ sin(0.5 * Month) * poly(Month, 1) + cos(0.1 * Month) * 
              poly(Month, 1) + tan(0.02*Month), data = EU.Sales.smootheddf)
global_pred <- predict(lmfit, Month = timevals_in)

# Convert global_pred to timeseries for plotting.
predicted <- ts(global_pred, frequency = 12, start = c(2011, 1))

# Compare original, smoothed, and predicted results.
plot(ts.build.EU.Sales,main = "Sales for EU Consumer(original vs Smoothed vs predicted)",xlab="Time",ylab="Sales") # Original data
lines(EU.Sales.smoothedseries, col = "blue")    # Smoothed (moving average)
lines(predicted, col = "red")                   # Predicted

accuracy(global_pred,EU.Sales.smootheddf$Sales)[5] # MAPE 13.72255

# Now, let's look at the locally predictable series. We will model it as an ARMA
# series.
local_pred <- ts.build.EU.Sales - global_pred
plot(local_pred, col = "red", type = "l")

# The plot shows no trend and no clear pattern. Test using ACF.
acf(local_pred)
# Most lags are in acceptable range but two are slightly outside. Try PACF function.

pacf(local_pred) # Some significant correlations up to lag ~ 0.4.  It seems that
# there may be some autoregressive behaviour remaining. Fit an ARMA model.
armafit <- auto.arima(local_pred)
tsdiag(armafit)
armafit # Best fit model ARIMA(0,0,0)(1,1,0) with log likelihood = -313.28 and
# AICc = 631.01

# Also test for stationarity using ADF and KPSS tests.
adf.test(local_pred, alternative = "stationary") # p-value 0.01 (stationary)
kpss.test(local_pred) # p-value >0.1 (stationary)

# So only white noise remains. Now evaluate the model using MAPE. First make a
# prediction for the last 6 months of data.

global_pred_out <- predict(lmfit, data.frame(Month = outdata$TS))

# Convert last 6 months actual data to timeseries for plotting.
actual <- ts(outdata$Monthly.Sales, frequency = 12, start = c(2014, 7))

# Compare our prediction with the actual values, using MAPE
MAPE_class_dec <- accuracy(global_pred_out, outdata$Monthly.Sales)[5]
MAPE_class_dec # 30.6975

# Plot the predictions along with original values, to get a visual feel of the fit.
class_dec_pred <- c(ts(global_pred), ts(global_pred_out))

# Convert class_dec_pred to timeseries for plotting.
class_dec_predicted <- ts(class_dec_pred, frequency = 12, start = c(2011, 1))
plot(totalts.build.EU.Sales, col = "black" ,main = "Sales for EU Consumer(original vs predicted",xlab="Time",ylab="Sales")         # Original data
lines(class_dec_predicted, col = "red")                  # Predictions

# Next build an auto ARIMA model.
autoarima.EU.Sales <- auto.arima(ts.build.EU.Sales)
autoarima.EU.Sales
# Selected an ARIMA(0,0,0)(1,1,0) model with AICc = 637.45 and log likelihood = -315.26.

autoarima_forecast <- forecast(ts.build.EU.Sales, h = 6)
autoarima_acc <- accuracy(autoarima_forecast, outdata$Monthly.Sales)
autoarima_acc
# MAPE = 19.09866 for Training set & 15.41908 for Validation set for Auto ARIMA

plot(autoarima_forecast)  # Forecast last 6 months
lines(actual)             # Actual last 6 months

# Evaluation of model for Consumer EU segment Sales.
# Visualise the Consumer EU Sales timeseries and auto ARIMA model.
plot(autoarima.EU.Sales$x, col = "black")
lines(fitted(autoarima.EU.Sales), col = "red")

# Check if the residual series is white noise
resi_auto_arima.EU.Sales <- ts.build.EU.Sales - fitted(autoarima.EU.Sales)
#resi_auto_arima.EU.Sales
adf.test(resi_auto_arima.EU.Sales, alternative = "stationary") # p-value 0.09775 (stationary)
kpss.test(resi_auto_arima.EU.Sales) # p-value >0.1 (stationary)

#Forecast for months 49 to 54(Jan 2015 to June 2015) using Auto ARIMA model
autoarima.EU.Salestotal <- auto.arima(totalts.build.EU.Sales)
autoarima.EU.Salestotal
autoarima_forecasttotal <- forecast(autoarima.EU.Salestotal,h=6)
plot(autoarima_forecasttotal)
autoarima_forecasttotal

############################## EU Consumer Quantity #################################

totalts.build.EU.Quantity <- ts(Consumer.EU$Monthly.Quantity,frequency = 12, start = c(2011, 1))
plot(totalts.build.EU.Quantity,main = "Quantity for EU Consumer",xlab="Time",ylab="Quantity")

#Let us begin to understand the individual components of our Quantity Time Series
ts.build.EU.Quantity.decompose <- decompose(totalts.build.EU.Quantity)
plot(ts.build.EU.Quantity.decompose, col = "blue")
## A linearly increasing upward trend with a positive slope and A low amplitude sinusoidal seasonality.

# Lets Build the time series model EU Consumer Quantity
ts.build.EU.Quantity <- ts(build.EU$Monthly.Quantity, frequency = 12,start = c(2011, 1))
# Plot the time series of EU Quantity to get an understanding of its pattern.
plot(ts.build.EU.Quantity,main = "Quantity for EU Consumer",xlab="Time",ylab="Quantity")

# Testing Holt winters for Smoothing
cols <- c("red", "blue", "green", "black")
alphas <- c(0.2, 0.4, 0.6)
labels <- c(paste("alpha =", alphas))
for (i in seq(1, length(alphas))) {
  smoothedseries <- HoltWinters(ts.build.EU.Quantity, alpha = alphas[i], beta = FALSE,
                                gamma = FALSE)
  lines(fitted(smoothedseries)[, 1], col = cols[i], lwd = 2)
}
legend("topleft", labels, col = cols, lwd = 2)
smoothedseries <- HoltWinters(ts.build.EU.Quantity, alpha = 0.4,beta = FALSE,
                              gamma = FALSE)

# Compare to moving average smoothing
EU.Quantity.smoothedseries <- stats::filter(ts.build.EU.Quantity, 
                                            filter = rep(1 / (2 * w + 1), (2 * w + 1)), 
                                            method = "convolution", sides = 2)

# Smoothing left end of the time series
diff <- EU.Quantity.smoothedseries[w + 2] - EU.Quantity.smoothedseries[w + 1]
for (i in seq(w, 1, -1)) {
  EU.Quantity.smoothedseries[i] <- EU.Quantity.smoothedseries[i + 1] - diff
}

# Smoothing right end of the time series
n <- length(ts.build.EU.Quantity)
diff <- EU.Quantity.smoothedseries[n - w] - EU.Quantity.smoothedseries[n - w - 1]
for (i in seq(n - w + 1, n)) {
  EU.Quantity.smoothedseries[i] <- EU.Quantity.smoothedseries[i - 1] + diff
}

# Plot the smoothed time series
plot(ts.build.EU.Quantity,main = "Quantity for EU Consumer moving average vs HoltWinters",xlab="Time",ylab="Quantity")
lines(EU.Quantity.smoothedseries, col = "blue", lwd = 2) # Moving average
lines(fitted(smoothedseries)[, 1], col = "red", lwd = 2) # Holt Winters

# Proceed using the moving average smoothed timeseries, to build a model by classical
# decomposition. First convert the time series to a dataframe.
EU.Quantity.smootheddf <- as.data.frame(cbind(timevals_in,
                                           as.vector(EU.Quantity.smoothedseries)))
colnames(EU.Quantity.smootheddf) <- c('Month', 'Quantity')

# Now, let's fit a multiplicative model with trend and seasonality to the data
# Seasonality will be modeled using a sinusoid function
lmfit <- lm(Quantity ~ sin(0.5 * Month) * poly(Month, 1) + cos(0.1 * Month) * 
              poly(Month, 1) + tan(0.02*Month), data = EU.Quantity.smootheddf)
global_pred <- predict(lmfit, Month = timevals_in)

# Convert global_pred to timeseries for plotting.
predicted <- ts(global_pred, frequency = 12, start = c(2011, 1))

# Compare original, smoothed, and predicted results.
plot(ts.build.EU.Quantity,main = "Quantity for EU Consumer original vs smoothed vs Predicted)",xlab="Time",ylab="Quantity")                         # Original data
lines(EU.Quantity.smoothedseries, col = "blue")    # Smoothed (moving average)
lines(predicted, col = "red")                      # Predicted

# Look at the locally predictable series. We will model it as an ARMA series
local_pred <- ts.build.EU.Quantity - global_pred
plot(local_pred, col = "red", type = "l")
# The plot shows no trend and no clear pattern. Test using ACF.
acf(local_pred)
# Most lags are in acceptable range. Try PACF function.

pacf(local_pred) # Some significant correlations up to lag ~ 0.4.  It seems that
# there may be some autoregressive behaviour remaining. Fit an ARMA model.
armafit <- auto.arima(local_pred)
tsdiag(armafit)
armafit # Best fit model ARIMA(0,0,0)(1,1,0) with log likelihood = -176.88 and
# AICc = 358.2

# Also test for stationarity using ADF and KPSS tests.
adf.test(local_pred, alternative = "stationary") # p-value <0.01 (stationary)
kpss.test(local_pred) # p-value >0.1 (stationary)

# So only white noise remains. Now evaluate the model using MAPE. First make a
# prediction for the last 6 months of data.
global_pred_out <- predict(lmfit, data.frame(Month = outdata$TS))

# Convert last 6 months actual data to timeseries for plotting.
actual <- ts(outdata$Monthly.Quantity, frequency = 12, start = c(2014, 7))

# Compare our prediction with the actual values, using MAPE
MAPE_EU_Quantity <- accuracy(global_pred_out, outdata$Monthly.Quantity)[5]
MAPE_EU_Quantity # 22.18186

# Plot the predictions along with original values, to get a visual feel of the fit.
class_dec_pred <- c(ts(global_pred), ts(global_pred_out))

# Convert class_dec_pred to timeseries for plotting.
class_dec_predicted <- ts(class_dec_pred, frequency = 12, start = c(2011, 1))
plot(totalts.build.EU.Quantity, col = "black",ylab="Quantity")
lines(class_dec_predicted, col = "red")

# Build the auto ARIMA model for comparison.
autoarima.EU.Quantity <- auto.arima(ts.build.EU.Quantity)
autoarima.EU.Quantity
autoarima_forecast <- forecast(autoarima.EU.Quantity, h = 6)
autoarima_acc <- accuracy(autoarima_forecast,outdata$Monthly.Quantity)
plot(autoarima_forecast)
lines(actual)             # Actual last 6 months
autoarima_acc
# MAPE = 13.00512 for Training set & 17.61852 for Validation set for Auto ARIMA
# Auto ARIMA has selected an ARIMA(0,0,0)(1,1,0) model, with AICc 362.37, log
# likelihood -177.72

# Evaluation of model for Consumer EU segment Quantity
# Visualise the Consumer EU Quantity timeseries and auto ARIMA model.
plot(autoarima.EU.Quantity$x, col = "black")
lines(fitted(autoarima.EU.Quantity), col = "red")

# Check if the residual series is white noise
resi_auto_arima.EU.Quantity <- ts.build.EU.Quantity - fitted(autoarima.EU.Quantity)

adf.test(resi_auto_arima.EU.Quantity, alternative = "stationary") # p-value 0.1801 (stationary)
kpss.test(resi_auto_arima.EU.Quantity) # p-value 0.1 (stationary)


#Forecast for months 49 to 54(Jan 2015 to June 2015) using Auto ARIMA model
autoarima.EU.Quantitytotal <- auto.arima(totalts.build.EU.Quantity)
autoarima.EU.Quantitytotal
autoarima_forecasttotal <- forecast(autoarima.EU.Quantitytotal,h=6)
plot(autoarima_forecasttotal)
autoarima_forecasttotal

############################## APAC Consumer Sales ##################################

Consumer.APAC <- filter(aggregated.monthly, Segment == "Consumer" & Market == "APAC")
build.APAC <- Consumer.APAC[1:42, ] # Build model from first 42 months' data.
outdata <- Consumer.APAC[43:48, ]   # Test model from 43 to 48 months data
totalts.build.APAC.Sales <- ts(Consumer.APAC$Monthly.Sales,frequency = 12, start = c(2011, 1)) # Whole time period
plot(totalts.build.APAC.Sales,main = "Sales for APAC Consumer",xlab="Time",ylab="Sales")

#Let us begin to understand the individual components of our Sales Time Series
ts.build.APAC.Sales.decompose <- decompose(totalts.build.APAC.Sales)
plot(ts.build.APAC.Sales.decompose, col = "blue")
## A linearly increasing trend with a positive slope and A low amplitude sinusoidal seasonality.

ts.build.APAC.Sales <- ts(build.APAC$Monthly.Sales, frequency = 12,start = c(2011, 1))         # First 42 months

# Visualise timeseries.
plot(ts.build.APAC.Sales,main = "Sales for APAC Consumer",xlab="Time",ylab="Sales")

# Testing Holt winters for Smoothing
cols <- c("red", "blue", "green", "black")
alphas <- c(0.2, 0.4, 0.6)
labels <- c(paste("alpha =", alphas))
for (i in seq(1,length(alphas))) {
  smoothedseries <- HoltWinters(ts.build.APAC.Sales, alpha = alphas[i], beta = FALSE,
                                gamma = FALSE)
  lines(fitted(smoothedseries)[,1], col = cols[i], lwd = 2)
}
legend("topleft", labels, col = cols, lwd = 2)
smoothedseries <- HoltWinters(ts.build.APAC.Sales, alpha = 0.4, beta = FALSE,
                              gamma = FALSE)

#Smoothing the series - Moving Average Smoothing
APAC.Sales.smoothedseries <- stats::filter(ts.build.APAC.Sales, 
                                           filter = rep(1 / (2 * w + 1), (2 * w + 1)), 
                                           method = "convolution", sides = 2)

# Smoothing left end of the time series
diff <- APAC.Sales.smoothedseries[w + 2] - APAC.Sales.smoothedseries[w + 1]
for (i in seq(w, 1, -1)) {
  APAC.Sales.smoothedseries[i] <- APAC.Sales.smoothedseries[i + 1] - diff
}

#Smoothing right end of the time series

n <- length(ts.build.APAC.Sales)
diff <- APAC.Sales.smoothedseries[n - w] - APAC.Sales.smoothedseries[n - w - 1]
for (i in seq(n - w + 1, n)) {
  APAC.Sales.smoothedseries[i] <- APAC.Sales.smoothedseries[i - 1] + diff
}

# Plot the smoothed time series
timevals_in <- build.APAC$TS
plot(ts.build.APAC.Sales,main = "Sales for APAC Consumer moving average vs HoltWinters",xlab="Time",ylab="Sales")
lines(APAC.Sales.smoothedseries, col = "blue", lwd = 2)    # Moving average
lines(fitted(smoothedseries)[, 1], col = "red", lwd = 2)   # Holt Winters

# Proceed with moving average smoothed data to create a model using classical
# decomposition. Convert the timeseries to a dataframe.
APAC.Sales.smootheddf <- as.data.frame(cbind(timevals_in, as.vector(APAC.Sales.smoothedseries)))
colnames(APAC.Sales.smootheddf) <- c("Month", "Sales")

# Now, let's fit a multiplicative model with trend and seasonality to the data
# Seasonality will be modeled using a sinusoid function
lmfit <- lm(Sales ~ sin(0.5 * Month) * poly(Month, 1) + cos(0.1 * Month) * 
              poly(Month, 1) + tan(0.02*Month), data = APAC.Sales.smootheddf)
global_pred <- predict(lmfit, Month = timevals_in)

# Convert global_pred to timeseries for plotting.
predicted <- ts(global_pred, frequency = 12, start = c(2011, 1))

plot(ts.build.APAC.Sales,main = "Sales for APAC Consumer original vs smoothed vs Predicted",xlab="Time",ylab="Sales")                                # Original data
lines(APAC.Sales.smoothedseries, col = "blue", lwd = 2)  # Smoothed data (moving avg)
lines(predicted, col = "red", lwd = 2)                   # Predictions

# Look at the locally predictable series and model it as an ARMA series.
local_pred <- ts.build.APAC.Sales - global_pred
plot(local_pred, col = "red", type = "l")

# The plot shows no trend and no clear pattern. Test using ACF.
acf(local_pred)
# Most lags are in acceptable range but one is slightly outside. Try PACF function.

pacf(local_pred) # Only one slightly significant lag. Fit an ARMA model.
armafit <- auto.arima(local_pred)
tsdiag(armafit)
armafit # Best fit model ARIMA(0,0,0)(1,0,0) with log likelihood = -444.41 and AICc =893.13

# Also test for stationarity using ADF and KPSS tests.
adf.test(local_pred, alternative = "stationary") # p-value <0.01 (stationary)
kpss.test(local_pred) # p-value >0.1 (stationary)

# So only white noise remains. Now evaluate the model using MAPE. First make a
# prediction for the last 6 months of data.
global_pred_out <- predict(lmfit, data.frame(Month = outdata$TS))

# Convert last 6 months actual data to timeseries for plotting.
actual <- ts(outdata$Monthly.Quantity, frequency = 12, start = c(2014, 7))

# Compare our prediction with the actual values, using MAPE
MAPE_APAC_sales <- accuracy(global_pred_out, outdata$Monthly.Sales)[5]
MAPE_APAC_sales # 22.53589

# Plot the predictions along with original values, to get a visual feel of the fit.
class_dec_pred <- c(ts(global_pred), ts(global_pred_out))

# Convert class_dec_pred to timeseries for plotting.
class_dec_predicted <- ts(class_dec_pred, frequency = 12, start = c(2011, 1))
plot(totalts.build.APAC.Sales, col = "black",ylab="Sales")             # Actual data
lines(class_dec_predicted, col = "red")                   # Predictions

# Build the auto ARIMA model for comparison.
autoarima.APAC.Sales <- auto.arima(ts.build.APAC.Sales)
autoarima.APAC.Sales
autoarima_forecast <- forecast(autoarima.APAC.Sales, h = 6)
autoarima_acc <- accuracy(autoarima_forecast, outdata$Monthly.Sales)
plot(autoarima_forecast)
lines(actual)             # Actual last 6 months
autoarima_acc
# MAPE = 17.68447 for Training set & 11.77618 for Validation set for Auto ARIMA.
# Auto ARIMA has selected an ARIMA(0,0,0)(1,1,0) model, with AICc 645.08, log
# likelihood -319.08

# Evaluation of model for APAC Sales segment Quantity
# Visualise the Consumer APAC Sales timeseries and auto ARIMA model.
plot(autoarima.APAC.Sales$x, col = "black")
lines(fitted(autoarima.APAC.Sales), col = "red")

# Check if the residual series is white noise
resi_auto_arima.APAC.Sales <- ts.build.APAC.Sales - fitted(autoarima.APAC.Sales)

adf.test(resi_auto_arima.APAC.Sales, alternative = "stationary") # p-value 0.0571 (stationary)
kpss.test(resi_auto_arima.APAC.Sales) # p-value 0.0571 (stationary)

#Forecast for months 49 to 54(Jan 2015 to June 2015) using Auto ARIMA model
autoarima.APAC.Salestotal <- auto.arima(totalts.build.APAC.Sales)
autoarima.APAC.Salestotal
autoarima_forecasttotal <- forecast(autoarima.APAC.Salestotal,h=6)
plot(autoarima_forecasttotal)
autoarima_forecasttotal


############################## APAC Consumer Quantity ###############################

totalts.build.APAC.Quantity <- ts(Consumer.APAC$Monthly.Quantity, frequency = 12,
                                  start = c(2011, 1))
plot(totalts.build.APAC.Quantity,main = "Quantity for APAC Consumer from 2011 to 2015",xlab="Time",ylab="Quantity")

#Let us begin to understand the individual components of our Quantity Time Series
ts.build.APAC.Quantity.decompose <- decompose(totalts.build.APAC.Quantity)
plot(ts.build.APAC.Quantity.decompose, col = "blue")
## A linearly increasing trend with a positive slope and A low amplitude sinusoidal seasonality.


ts.build.APAC.Quantity <- ts(build.APAC$Monthly.Quantity, frequency = 12,
                             start = c(2011, 1))

# Now, we will plot the time series of APAC Quantity to get an understanding of its
# pattern.
plot(ts.build.APAC.Quantity,main = "Quantity for APAC Consumer",xlab="Time",ylab="Quantity")

#Testing Holt winters for Smoothing
cols <- c("red", "blue", "green", "black")
alphas <- c(0.2, 0.4, 0.6)
labels <- c(paste("alpha =", alphas))
for (i in seq(1, length(alphas))) {
  smoothedseries <- HoltWinters(ts.build.APAC.Quantity, alpha = alphas[i], beta=FALSE,
                                gamma = FALSE)
  lines(fitted(smoothedseries)[, 1], col = cols[i], lwd = 2)
}
legend("topleft", labels, col = cols, lwd = 2)
smoothedseries <- HoltWinters(ts.build.APAC.Quantity, alpha = 0.4, beta = FALSE,
                              gamma = FALSE)

# Compare to moving average smoothing.
APAC.Quantity.smoothedseries <- stats::filter(ts.build.APAC.Quantity, 
                                              filter = rep(1 / (2 * w + 1), (2 * w + 1)), 
                                              method = "convolution", sides = 2)

#Smoothing left end of the time series
diff <- APAC.Quantity.smoothedseries[w+2] - APAC.Quantity.smoothedseries[w + 1]
for (i in seq(w, 1, -1)) {
  APAC.Quantity.smoothedseries[i] <- APAC.Quantity.smoothedseries[i + 1] - diff
}

# Smoothing right end of the time series
n <- length(ts.build.APAC.Quantity)
diff <- APAC.Quantity.smoothedseries[n - w] - APAC.Quantity.smoothedseries[n - w - 1]
for (i in seq(n - w + 1, n)) {
  APAC.Quantity.smoothedseries[i] <- APAC.Quantity.smoothedseries[i - 1] + diff
}

# Plot the smoothed time series
timevals_in <- build.APAC$TS
plot(ts.build.APAC.Quantity,main = "Quantity for APAC Consumer",xlab="Time",ylab="Quantity")
lines(APAC.Quantity.smoothedseries, col = "blue", lwd = 2)
lines(fitted(smoothedseries)[, 1], col = "red", lwd = 2)

# Building a model on the smoothed time series using classical decomposition.
# First, let's convert the time series to a dataframe.
APAC.Quantity.smootheddf <- as.data.frame(cbind(timevals_in,
                                                as.vector(APAC.Quantity.smoothedseries)))
colnames(APAC.Quantity.smootheddf) <- c("Month", "Quantity")

# Now, let's fit a multiplicative model with trend and seasonality to the data
# Seasonality will be modeled using a sinusoid function
lmfit <- lm(Quantity ~ sin(0.5 * Month) * poly(Month, 1) + cos(0.1 * Month) * 
              poly(Month, 1) + tan(0.02*Month), data = APAC.Quantity.smootheddf)
global_pred <- predict(lmfit, Month = timevals_in)

# Convert global_pred to timeseries for plotting.
predicted <- ts(global_pred, frequency = 12, start = c(2011, 1))

plot(ts.build.APAC.Quantity,main = "Quantity for APAC Consumer",xlab="Time",ylab="Quantity")                                # Original data
lines(APAC.Quantity.smoothedseries, col = "blue", lwd = 2)  # Smoothed data (moving avg)
lines(predicted, col = "red", lwd = 2)                      # Predictions

# Now, let's look at the locally predictable series and model it as an ARMA series.
local_pred <- ts.build.APAC.Quantity - global_pred
plot(local_pred, col='red', type = "l")

# The plot shows no trend and no clear pattern. Test using ACF.
acf(local_pred)
# Most lags are in acceptable range but three are slightly outside. Try PACF function.

pacf(local_pred) # Some significant lags up to 5. Fit an ARMA model.
armafit <- auto.arima(local_pred)
tsdiag(armafit)
armafit # Best fit model ARIMA(0,0,0)(1,1,0)[12] with log likelihood = -177.62 and AICc = 359.68

# Also test for stationarity using ADF and KPSS tests.
adf.test(local_pred, alternative = "stationary") # p-value <0.01 (stationary)
kpss.test(local_pred) # p-value >0.1 (stationary)

# So only white noise remains. Now evaluate the model using MAPE. First make a
# prediction for the last 6 months of data.
global_pred_out <- predict(lmfit, data.frame(Month = outdata$TS))

# Convert last 6 months actual data to timeseries for plotting.
actual <- ts(outdata$Monthly.Quantity, frequency = 12, start = c(2014, 7))

# Compare our prediction with the actual values, using MAPE
MAPE_APAC_Quantity <- accuracy(global_pred_out, outdata$Monthly.Quantity)[5]
MAPE_APAC_Quantity # 18.79196

# Plot the predictions along with original values, to get a visual feel of the fit.
class_dec_pred <- c(ts(global_pred), ts(global_pred_out))
class_dec_predicted <- ts(class_dec_pred, frequency = 12, start = c(2011, 1))
plot(totalts.build.APAC.Quantity, col = "black",ylab="Quantity")            # Actual data
lines(class_dec_predicted, col = "red")                     # Predictions

# Build auto ARIMA model for comparison.
autoarima.APAC.Quantity <- auto.arima(ts.build.APAC.Quantity)
autoarima.APAC.Quantity
autoarima_forecast <- forecast(autoarima.APAC.Quantity, h = 6)
autoarima_acc <- accuracy(autoarima_forecast, outdata$Monthly.Quantity)
plot(autoarima_forecast) # Forecast last 6 months
lines(actual)             # Actual last 6 months
autoarima_acc
# MAPE=15.03335 for Training set & 13.36779 for Validation set for Auto ARIMA
# Auto ARIMA has selected an ARIMA(0,0,0)(1,1,0) model, with AICc 366.2, log likelihood
# -179.64.

# Evaluation of model for Consumer APAC segment Quantity
# Visualise the Consumer APAC Quantity timeseries and auto ARIMA model.
plot(autoarima.APAC.Quantity$x, col = "black",ylab="Quantity")
lines(fitted(autoarima.APAC.Quantity), col = "red")

# Check if the residual series is white noise
resi_auto_arima.APAC.Quantity <- ts.build.APAC.Quantity - fitted(autoarima.APAC.Quantity)

adf.test(resi_auto_arima.APAC.Quantity, alternative = "stationary") # p-value 0.1573 (stationary)
kpss.test(resi_auto_arima.APAC.Quantity) # p-value 0.1 (stationary)

#Forecast for months 49 to 54(Jan 2015 to June 2015) using Auto ARIMA model
autoarima.APAC.Quantitytotal <- auto.arima(totalts.build.APAC.Quantity)
autoarima.APAC.Quantitytotal
autoarima_forecasttotal <- forecast(autoarima.APAC.Quantitytotal,h=6)
plot(autoarima_forecasttotal)
autoarima_forecasttotal


######################## Summary #######################
###  MAPE Values
#Classical decomposition
#--------------------------|
#   	    |  EU	  |  APAC  |
#---------|-------|--------|
#Sales	  |30.69	| 22.53  |
#Quantity	|22.18	| 18.79  |
#--------------------------|

#Auto arima			
#----------------------------------------------------|
#          EU		               |         APAC	       |
#----------------------------------------------------|
#          Train   |  Test     |  Train    | Test    |
#------------------|-----------------------|---------|
#Sales	  19.09866 |	15.41908 |	17.68447 | 11.77618|
#Quantity	13.00512 |	17.61852 |	15.03335 | 13.36779|
#----------------------------------------------------|

###Auto Arima is the a satisfactory model based on MAPE Values than classical decomposition