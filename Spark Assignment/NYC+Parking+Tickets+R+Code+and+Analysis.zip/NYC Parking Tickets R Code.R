#########################################################################################
#############NYC Parking Tickets: An Exploratory Analysis - SparkR Case Study ###########
#########################################################################################

### Objective : To get familiarity with how analysis works in SparkR as opposed to base R

### Data Analysis : The NYC Police Department has collected data for parking tickets we are using the data files from 2014 to 2017 are publicly available on Kaggle.
### We will try and perform some exploratory analysis on this data 

### Data Location : The data for this case study has been used from HDFS at the following path:

### '/common_folder/nyc_parking/Parking_Violations_Issued_-_Fiscal_Year_201x.csv' where 'x' is between {5,6,7}

### scope of this analysis, we wish to compare the phenomenon related to parking tickets over three different years - 2015, 2016, 2017
### The Analysis will be performed on the R-studio interface using SparkR package running on an Corestack Lab.



### Assumptions : Assumptions and observations are stated in comments.

######################################################################################
# Getting ready for analysis and Loading the data                                    #                     
######################################################################################
# Load SparkR.
spark_path <- '/usr/local/spark'
if (nchar(Sys.getenv("SPARK_HOME")) < 1) {
  Sys.setenv(SPARK_HOME = spark_path)
}
library(SparkR, lib.loc = c(file.path(Sys.getenv("SPARK_HOME"), "R", "lib")))

# Load other libraries.
library(stringr)
library(ggplot2)
library(ggthemes)

# Initialise the sparkR session.
sparkR.session(master = "yarn-client", sparkConfig = list(spark.driver.memory = "1g"))

# Clear environment variables.
rm(list=ls())

# Create a Spark DataFrame for each year's data.
data_2015 <- read.df("hdfs:///common_folder/nyc_parking/Parking_Violations_Issued_-_Fiscal_Year_2015.csv", source = "csv",
                     header = TRUE, inferSchema = TRUE)

data_2016 <- read.df("hdfs:///common_folder/nyc_parking/Parking_Violations_Issued_-_Fiscal_Year_2016.csv", source = "csv",
                     header = TRUE, inferSchema = TRUE)

data_2017 <- read.df("hdfs:///common_folder/nyc_parking/Parking_Violations_Issued_-_Fiscal_Year_2017.csv", source = "csv",
                     header = TRUE, inferSchema = TRUE)

#####################################################################################
# EDA of data.                                                                      #
#####################################################################################
dim(data_2015)  # 2015 data set has 11,809,233 with 51 observations
head(data_2015) # there are many columns with NA's
str(data_2015) 
printSchema(data_2015)
colnames(data_2015) # Column names has ? and space

dim(data_2016)  # 2016 data set has 10,626,899 with 51 observations
head(data_2016) # there are many columns with NA's
str(data_2016) 
printSchema(data_2016)
colnames(data_2016)

dim(data_2017)  # 2017 data set has 10,803,028 with 43 observations
head(data_2017) # there are some columns with NA's
str(data_2017)
printSchema(data_2017)
colnames(data_2017)

# Column headers for each dataset include spaces, remove these characters.There are spaces at the end and "?"
colnames(data_2015) <- str_replace_all(colnames(data_2015),
                                       pattern = " ", replacement = "")
colnames(data_2015) <- str_replace_all(colnames(data_2015),
                                       pattern="\\?", replacement = "")
#colnames(data_2015) <- str_trim(colnames(data_2015), side= "both")
colnames(data_2016) <- str_replace_all(colnames(data_2016),
                                       pattern = " ", replacement = "")
colnames(data_2016) <- str_replace_all(colnames(data_2016),
                                       pattern="\\?", replacement = "")
#colnames(data_2016) <- str_trim(colnames(data_2016), side= "both")
colnames(data_2017) <- str_replace_all(colnames(data_2017),
                                       pattern = " ", replacement = "")
colnames(data_2017) <- str_replace_all(colnames(data_2017),
                                       pattern="\\?", replacement = "")
#colnames(data_2017) <- str_trim(colnames(data_2017), side= "both") 
colnames(data_2015)
colnames(data_2016)
colnames(data_2017)


# Add a jar file in RStudio to allow execution of hive-sql queries from RStudio.
sql("ADD JAR /opt/cloudera/parcels/CDH/lib/hive/lib/hive-hcatalog-core-1.1.0-cdh5.11.2.jar")

# Create temporary views for each year, for using SQL.
createOrReplaceTempView(data_2015, "data_2015_tbl")
createOrReplaceTempView(data_2016, "data_2016_tbl")
createOrReplaceTempView(data_2017, "data_2017_tbl")

### 2015 data set - EDA

# Lets' drop the columns which are not aligned between datasets.


data_2015_nullcount <- SparkR::sql("SELECT COUNT(*) Num_of_Rows,
                                   SUM(CASE WHEN PlateID IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) nullsPlateID,
                                   SUM(CASE WHEN NoStandingorStoppingViolation IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) nullsstandstop,
                                   SUM(CASE WHEN HydrantViolation IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) nullsHydrantViolation,
                                   SUM(CASE WHEN DoubleParkingViolation IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) nullsDoubleParkingViolation,
                                   SUM(CASE WHEN Latitude IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) NullsLatitude,
                                   SUM(CASE WHEN Longitude IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) NullsLongitude,
                                   SUM(CASE WHEN CommunityBoard IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) NullsCommunityBoard,
                                   SUM(CASE WHEN CommunityCouncil IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) NullsCommunityCouncil,
                                   SUM(CASE WHEN CensusTract IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) NullsCensusTract,
                                   SUM(CASE WHEN BIN IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) NullsBIN,
                                   SUM(CASE WHEN BBL IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) NullsBBL,
                                   SUM(CASE WHEN NTA IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) NullsNTA
                                   FROM data_2015_tbl")
head(data_2015_nullcount)
# Mostly All are NA values in No_Standing_or_Stopping_Violation,Hydrant_Violation,Double_Parking_Violation,Latitude,Longitude,Community_Board,Community_Council,Census_Tract,BIN,BBL,NTA except in plate_ID.
# So we can drop these columns from the data set 2015.

#Removing these Null Columns which are not there in 2017 or which has just nulls in all 3 datasets.
data_2015<- drop(data_2015, c("NoStandingorStoppingViolation","HydrantViolation","DoubleParkingViolation","Latitude","Longitude","CommunityBoard", "CommunityCouncil","CensusTract","BIN" , "BBL",  "NTA") )
colnames(data_2015)
dim(data_2015) # 11,809,233   records with 40 attributes

createOrReplaceTempView(data_2015, "data_2015_tbl")

# As per data dictionary from Kaggle Summons number is unique so we are checking duplciates and dropping in the next steps.
# Lets check if  Summons Number  column has duplciates in 2015.
data_2015_duplicates <- SparkR::sql("SELECT SummonsNumber,count(*) FROM data_2015_tbl group by SummonsNumber HAVING count(*) > 1")
#head(data_2015_duplicates) 
nrow(data_2015_duplicates) # 809,112 duplicates in 2015 dataset.

# Lets check unique SummonsNumber count in 2015 .
data_2015_unique <- SparkR::sql("SELECT count(distinct SummonsNumber) FROM data_2015_tbl")
head(data_2015_unique) # 10,951,256 are unique records in 2015 dataset.

### Unique Summons_Number are 10,951,256 so there are lot of duplciates(809,112) lets' drop the duplciates in 2015 dataset.

data_2015<- dropDuplicates(data_2015, "SummonsNumber")
dim(data_2015) # after drop total records in 2015 dataset are 10,951,256

createOrReplaceTempView(data_2015, "data_2015_tbl")

# Checking on some date columns like Issue date,VehicleExpirationDate,DateFirstObserved columns if there are any data issues in 2015 dataset

data_2015_nullissuedate <- SparkR::sql("SELECT SUM(CASE WHEN IssueDate IS NULL
                                       THEN 1
                                       ELSE 0
                                       END) nulls_Issue_Date,
                                       COUNT(*) Num_of_Rows
                                       FROM data_2015_tbl")
head(data_2015_nullissuedate)
#There are no records with missing Issue Date or Null in Issue Date.

# IssueDate is in the format MM/DD/YYYY. Convert to date type and then extract the
# month and Year in a new column.
# Convert VehicleExpirationDate, DateFirstObserved to date type
data_2015$IssueDate <- to_date(data_2015$IssueDate, 'MM/dd/yyyy')
data_2015$VehicleExpirationDate <- to_date(data_2015$VehicleExpirationDate, 'yyyyMMdd')
data_2015$DateFirstObserved <- to_date(data_2015$DateFirstObserved, 'yyyyMMdd')
# Update view for SQL querying.
createOrReplaceTempView(data_2015, "data_2015_tbl")

#Let's check on if any issues other issues in Issue Date column

data_2015_dateRange_Issue <- SparkR::sql("SELECT min(issuedate)as Min_IssueDate_2015,
                                         max(issuedate)as Max_IssueDate_2015
                                         FROM data_2015_tbl")
head(data_2015_dateRange_Issue)
# Min_IssueDate_2015 : 1985-07-16
# Max_IssueDate_2015 : 2015-06-30
# The Issue Tickets range between 16th July 1985 to 30th June 2015. There are issues with issue date column.

data_2015$IssueMonth <- month(data_2015$IssueDate)
data_2015$IssueYear <- year(data_2015$IssueDate)

# Update view for SQL querying.
createOrReplaceTempView(data_2015, "data_2015_tbl")

data_2015_group <- SparkR::sql("SELECT IssueYear,
                               IssueMonth,
                               count(*) as TotalCount
                               FROM data_2015_tbl
                               GROUP BY IssueYear,
                               IssueMonth
                               ORDER BY 1,2")


data_2015_dfgrouped_issue <- data.frame(head(data_2015_group, nrow(data_2015_group)))
View(data_2015_dfgrouped_issue)

# This column is the key for parking tickets so we have decided to filter the records 
# from the July of Pervious Year to June of the Current Year.

data_2015 <- data_2015[
  data_2015$IssueDate >= "2014-07-01" & 
    data_2015$IssueDate <= "2015-06-30"]

dim(data_2015) # 10,598,035 records after filtering.

# Update view for SQL querying.
createOrReplaceTempView(data_2015, "data_2015_tbl")


##################################################################

### 2016 dataset -EDA ####

data_2016_nullcount <- SparkR::sql("SELECT COUNT(*) Num_of_Rows,
                                   SUM(CASE WHEN PlateID IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) nullsPlateID,
                                   SUM(CASE WHEN NoStandingorStoppingViolation IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) nullsstandstop,
                                   SUM(CASE WHEN HydrantViolation IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) nullsHydrantViolation,
                                   SUM(CASE WHEN DoubleParkingViolation IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) nullsDoubleParkingViolation,
                                   SUM(CASE WHEN Latitude IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) NullsLatitude,
                                   SUM(CASE WHEN Longitude IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) NullsLongitude,
                                   SUM(CASE WHEN CommunityBoard IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) NullsCommunityBoard,
                                   SUM(CASE WHEN CommunityCouncil IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) NullsCommunityCouncil,
                                   SUM(CASE WHEN CensusTract IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) NullsCensusTract,
                                   SUM(CASE WHEN BIN IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) NullsBIN,
                                   SUM(CASE WHEN BBL IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) NullsBBL,
                                   SUM(CASE WHEN NTA IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) NullsNTA
                                   FROM data_2016_tbl")
head(data_2016_nullcount)
# All are NA values in No_Standing_or_Stopping_Violation,Hydrant_Violation,Double_Parking_Violation,Latitude,Longitude,Community_Board,Community_Council,Census_Tract,BIN,BBL,NTA except in plate_ID.
# So we can drop these columns from the data set 2016.

#Removing these Null Columns which are not sync with 2017 dataset.
data_2016<- drop(data_2016, c("NoStandingorStoppingViolation","HydrantViolation","DoubleParkingViolation","Latitude","Longitude","CommunityBoard", "CommunityCouncil","CensusTract","BIN" , "BBL",  "NTA") )
colnames(data_2016)
dim(data_2016) # 10,626,899 records and 40 attributes

createOrReplaceTempView(data_2016, "data_2016_tbl")

# Lets check if  SummonsNumber  column has duplciates in 2016.
data_2016_duplicates <- SparkR::sql("SELECT SummonsNumber,count(*) FROM data_2016_tbl group by SummonsNumber HAVING count(*) > 1")
#head(data_2016_duplicates)
nrow(data_2016_duplicates) # 0 duplciates in 2016 dataset.

# Lets check unique SummonsNumber count in 2016 .
data_2016_unique <- SparkR::sql("SELECT count(distinct SummonsNumber) FROM data_2016_tbl")
head(data_2016_unique) # 10,626,899 unique records.

### Unique Summons Number are 10,626,899 so there are no duplciates in 2016 dataset.

# Checking on some date columns like Issue date,VehicleExpirationDate,DateFirstObserved columns if there are any data issues in 2016 dataset

data_2016_nullissuedate <- SparkR::sql("SELECT SUM(CASE WHEN IssueDate IS NULL
                                       THEN 1
                                       ELSE 0
                                       END) nulls_Issue_Date,
                                       COUNT(*) Num_of_Rows
                                       FROM data_2016_tbl")
head(data_2016_nullissuedate)
#There are no records with missing Issue Date or Null Issue Date.

# IssueDate is in the format MM/DD/YYYY. Convert to date type and then extract the
# month and Year in a new column.
# Convert VehicleExpirationDate, DateFirstObserved to date type
data_2016$IssueDate <- to_date(data_2016$IssueDate, 'MM/dd/yyyy')
data_2016$VehicleExpirationDate <- to_date(cast(data_2016$VehicleExpirationDate,"string"), 'yyyyMMdd')
data_2016$DateFirstObserved <- to_date(cast(data_2016$DateFirstObserved,"string"), 'yyyyMMdd')
# Update view for SQL querying.
createOrReplaceTempView(data_2016, "data_2016_tbl")

#Let's check on if any issues in Issue Date

data_2016_dateRange_Issue <- SparkR::sql("SELECT min(issuedate)as Min_IssueDate_2016,
                                         max(issuedate)as Max_IssueDate_2016
                                         FROM data_2016_tbl")
head(data_2016_dateRange_Issue)
# Min IssueDate 2016 : 1970-04-13
# Max IssueDate 2016 : 2069-10-02
# The Issue Tickets range between 1970-04-13 to 2069-10-02. There is issues with dates 
# Let us Analyze this parameter closely to decide optimal filter condition.

data_2016$IssueMonth <- month(data_2016$IssueDate)
data_2016$IssueYear <- year(data_2016$IssueDate)
# Update view for SQL querying.
createOrReplaceTempView(data_2016, "data_2016_tbl")

data_2016_group <- SparkR::sql("SELECT IssueYear,
                               IssueMonth,
                               count(*) as TotalCount
                               FROM data_2016_tbl
                               GROUP BY IssueYear,
                               IssueMonth
                               ORDER BY 1,2")

data_2016_dfgrouped_issue <- data.frame(head(data_2016_group, nrow(data_2016_group)))
View(data_2016_dfgrouped_issue)

# This column is the key for parking tickets so we have decided to filter the records 
# from the July of Pervious Year to June of the Current Year.

data_2016 <- data_2016[
  data_2016$IssueDate >= "2015-07-01" & 
    data_2016$IssueDate <= "2016-06-30"]

dim(data_2016) # 10396894 records after filtering.

# Update view for SQL querying.
createOrReplaceTempView(data_2016, "data_2016_tbl")

############# 2017 dataset - EDA ###############

data_2017_nullcount <- SparkR::sql("SELECT COUNT(*) Num_of_Rows,
                                   SUM(CASE WHEN PlateID IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) nullsPlateID,
                                   SUM(CASE WHEN NoStandingorStoppingViolation IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) nullsstandstop,
                                   SUM(CASE WHEN HydrantViolation IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) nullsHydrantViolation,
                                   SUM(CASE WHEN DoubleParkingViolation IS NULL
                                   THEN 1
                                   ELSE 0
                                   END) nullsDoubleParkingViolation
                                   FROM data_2017_tbl")
head(data_2017_nullcount)
# All are NA values in No_Standing_or_Stopping_Violation,Hydrant_Violation,Double_Parking_Violation except in plate_ID.
# So we can drop these columns from the data set 2017.

#Removing these Null Columns which are same as with 2015,2016 dataset.
data_2017<- drop(data_2017, c("NoStandingorStoppingViolation","HydrantViolation","DoubleParkingViolation") )
colnames(data_2017)
dim(data_2017) # 10,803,028   Records with 40 attributes.

createOrReplaceTempView(data_2017, "data_2017_tbl")

# Lets check if  Summons_Number  column has duplciates in 2017.
data_2017_duplicates <- SparkR::sql("SELECT SummonsNumber,count(*) FROM data_2017_tbl group by SummonsNumber HAVING count(*) > 1")
#head(data_2017_duplicates)
nrow(data_2017_duplicates) # 0 duplciates in 2017 dataset.

# Lets check unique SummonsNumber count in 2017 .
data_2017_unique <- SparkR::sql("SELECT count(distinct SummonsNumber) FROM data_2017_tbl")
head(data_2017_unique) # 10,803,028 unique records.

### Unique Summons Number are 10,803,028 so there are no duplciates in 2017 dataset.

# Checking on some date columns like Issue date,VehicleExpirationDate,DateFirstObserved columns if there are any data issues in 2017 dataset

data_2017_nullissuedate <- SparkR::sql("SELECT SUM(CASE WHEN IssueDate IS NULL
                                       THEN 1
                                       ELSE 0
                                       END) nulls_Issue_Date,
                                       COUNT(*) Num_of_Rows
                                       FROM data_2017_tbl")
head(data_2017_nullissuedate)
#There are no records with missing Issue Date or Null Issue Date.

# IssueDate is in the format MM/DD/YYYY. Convert to date type and then extract the
# month and Year in a new column.
# Convert VehicleExpirationDate, DateFirstObserved to date type
data_2017$IssueDate <- to_date(data_2017$IssueDate, 'MM/dd/yyyy')
data_2017$VehicleExpirationDate <- to_date(cast(data_2017$VehicleExpirationDate,"string"), 'yyyyMMdd')
data_2017$DateFirstObserved <- to_date(cast(data_2017$DateFirstObserved,"string"), 'yyyyMMdd')
# Update view for SQL querying.
createOrReplaceTempView(data_2017, "data_2017_tbl")

#Let's check on if any issues in Issue Date

data_2017_dateRange_Issue <- SparkR::sql("SELECT min(issuedate)as Min_IssueDate_2017,
                                         max(issuedate)as Max_IssueDate_2017
                                         FROM data_2017_tbl")
head(data_2017_dateRange_Issue)
# Min IssueDate 2017 : 1972-03-30
# Max IssueDate 2017 : 2069-11-19
# The Issue Tickets range between 1972-03-30 to 2069-11-19. There is issues with dates 
# Let us Analyze this parameter closely to decide optimal filter condition.

data_2017$IssueMonth <- month(data_2017$IssueDate)
data_2017$IssueYear <- year(data_2017$IssueDate)

# Update view for SQL querying.
createOrReplaceTempView(data_2017, "data_2017_tbl")

data_2017_group <- SparkR::sql("SELECT IssueYear,
                               IssueMonth,
                               count(*) as TotalCount
                               FROM data_2017_tbl
                               GROUP BY IssueYear,
                               IssueMonth
                               ORDER BY 1,2")

data_2017_dfgrouped_issue <- data.frame(head(data_2017_group, nrow(data_2017_group)))
View(data_2017_dfgrouped_issue)

# This column is the key for parking tickets so we have decided to filter the records 
# from the July of Pervious Year to June of the Current Year.

data_2017 <- data_2017[
  data_2017$IssueDate >= "2016-07-01" & 
    data_2017$IssueDate <= "2017-06-30"]

dim(data_2017) # 10,539,563 records after filtering.

# Update view for SQL querying.
createOrReplaceTempView(data_2017, "data_2017_tbl")

### Basic EDA is complete here in 2015 ,2016,2017 datasets other column issues are handled in need basis while answering Questions.

######################################################################################
# Examine the data                                                                   #
######################################################################################

# 1) Find the total number of tickets for each year.

nrow(data_2015)   # 10,598,035 tickets issue in 2015.
nrow(data_2016)   # 10,396,894 tickets issue in 2016.
nrow(data_2017)   # 10,539,563 tickets issue in 2017.


Total_Number_of_Tickets <- c(nrow(data_2015),nrow(data_2016),nrow(data_2017))
Year_Labels <- c("Year_2015", "Year_2016", "Year_2017")
Total_tickets_vs_year <- data.frame(Total_Number_of_Tickets, Year_Labels)

ggplot(Total_tickets_vs_year, aes(x=reorder(Year_Labels,-Total_Number_of_Tickets), y=Total_Number_of_Tickets))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Year", y = "Total Number of Tickets", title = "Total Number of Tickets by Year") +
  geom_text(aes(label=Total_Number_of_Tickets),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")


#####################################################################################

# 2a) Find out the number of unique states from where the cars that got parking tickets
# came from. 
states2015 <- SparkR::sql("SELECT DISTINCT RegistrationState AS State,
                          COUNT (RegistrationState) AS Frequency
                          FROM data_2015_tbl
                          GROUP BY State
                          ORDER BY Frequency DESC")
nrow(states2015)   # 69 unique states in 2015.

states2016 <- SparkR::sql("SELECT DISTINCT RegistrationState AS State,
                          COUNT (RegistrationState) AS Frequency
                          FROM data_2016_tbl
                          GROUP BY State
                          ORDER BY Frequency DESC")
nrow(states2016)   # 68 unique states in 2016.

states2017 <- SparkR::sql("SELECT DISTINCT RegistrationState AS State,
                          COUNT (RegistrationState) AS Frequency
                          FROM data_2017_tbl
                          GROUP BY State
                          ORDER BY Frequency DESC")
nrow(states2017)   # 67 unique states in 2017.


number_of_unique_states<- c(nrow(states2015), nrow(states2016), nrow(states2017))
Year_Labels<- c("Year_2015", "Year_2016", "Year_2017")
number_of_unique_states_vs_year<- data.frame(number_of_unique_states, Year_Labels)

ggplot(number_of_unique_states_vs_year, aes(x=reorder(Year_Labels,-number_of_unique_states), y=number_of_unique_states))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Year", y = "Number of unique states", title = "Number of unique states by Year") +
  geom_text(aes(label=number_of_unique_states),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")


#####################################################################################

# 2b) There is a numeric entry in the column which should be corrected. Replace it with
# the state having maximum entries. Give the number of unique states for each year
# again.

#states2015 <- SparkR::sql("SELECT DISTINCT RegistrationState AS State
#                          FROM data_2015_tbl
#                          WHERE RegistrationState NOT LIKE '%[^0-9]%'")
#head(states2015)

showDF(states2015, 69, FALSE) # Invalid entries include numeric entry: 99.
showDF(states2016, 68, FALSE) # Invalid entries include numeric entry: 99.
showDF(states2017, 67, FALSE) # Invalid entries include numeric entry: 99.
# We an see that the only numeric entry for each year is "99" and that the state with
# maximum entries each year is "NY". Replace each occurrence of "99" with "NY".
data_2015$RegistrationState <- regexp_replace(data_2015$RegistrationState,
                                              pattern = "99", replacement = "NY")
data_2016$RegistrationState <- regexp_replace(data_2016$RegistrationState,
                                              pattern = "99", replacement = "NY")
data_2017$RegistrationState <- regexp_replace(data_2017$RegistrationState,
                                              pattern = "99", replacement = "NY")

# Update the SQL views for further analysis.
createOrReplaceTempView(data_2015, "data_2015_tbl")
createOrReplaceTempView(data_2016, "data_2016_tbl")
createOrReplaceTempView(data_2017, "data_2017_tbl")

# After replacing the values, Count the number of unique state again
states2015 <- SparkR::sql("SELECT DISTINCT RegistrationState AS State,
                          COUNT (RegistrationState) AS Frequency
                          FROM data_2015_tbl
                          GROUP BY State
                          ORDER BY Frequency DESC")
nrow(states2015)   # 68 unique states in 2015.

states2016 <- SparkR::sql("SELECT DISTINCT RegistrationState AS State,
                          COUNT (RegistrationState) AS Frequency
                          FROM data_2016_tbl
                          GROUP BY State
                          ORDER BY Frequency DESC")
nrow(states2016)   # 67 unique states in 2016.

states2017 <- SparkR::sql("SELECT DISTINCT RegistrationState AS State,
                          COUNT (RegistrationState) AS Frequency
                          FROM data_2017_tbl
                          GROUP BY State
                          ORDER BY Frequency DESC")
nrow(states2017)   # 66 unique states in 2017.


number_of_unique_states<- c(nrow(states2015), nrow(states2016), nrow(states2017))
Year_Labels<- c("Year_2015", "Year_2016", "Year_2017")
number_of_unique_states_vs_year<- data.frame(number_of_unique_states, Year_Labels)

ggplot(number_of_unique_states_vs_year, aes(x=reorder(Year_Labels,-number_of_unique_states), y=number_of_unique_states))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Year", y = "Number of unique states", title = "Number of unique states by Year") +
  geom_text(aes(label=number_of_unique_states),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

#####################################################################################

# 3) Some parking tickets don't have the address for violation location on them, which
# is a cause for concern. Write a query to check the number of such tickets. The
# values should not be deleted or imputed here. This is just a check.

# Address fields are HouseNumber and StreetName
addresses2015 <- SparkR::sql("SELECT HouseNumber, StreetName
                             FROM data_2015_tbl
                             WHERE HouseNumber IS NULL OR StreetName IS NULL")
nrow(addresses2015)   # 1,622,076 tickets in 2015 with incomplete addresses.

addresses2016 <- SparkR::sql("SELECT HouseNumber, StreetName
                             FROM data_2016_tbl
                             WHERE HouseNumber IS NULL OR StreetName IS NULL")
nrow(addresses2016)   # 1,963,921 tickets in 2016 with incomplete addresses.

addresses2017 <- SparkR::sql("SELECT HouseNumber, StreetName
                             FROM data_2017_tbl
                             WHERE HouseNumber IS NULL OR StreetName IS NULL")
nrow(addresses2017)   # 2,160,639 tickets in 2017 with incomplete addresses.

number_of_tickets_no_address<- c(nrow(addresses2015), nrow(addresses2016), nrow(addresses2017))
Year_Labels<- c("Year_2015", "Year_2016", "Year_2017")
number_of_tickets_no_address_vs_year<- data.frame(number_of_tickets_no_address, Year_Labels)

ggplot(number_of_tickets_no_address_vs_year, aes(x=reorder(Year_Labels,-number_of_tickets_no_address), y=number_of_tickets_no_address))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Year", y = "Number of Tickets", title = "Number of Tickets with out address by Year") +
  geom_text(aes(label=number_of_tickets_no_address),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

######################################################################################
# Aggregation tasks                                                                  #
######################################################################################

# 1) How often does each violation code occur? Display the frequency of the top five
# violation codes.
violationCodes2015 <- SparkR::sql("SELECT ViolationCode, Count(ViolationCode) AS Count
                                  FROM data_2015_tbl
                                  GROUP BY ViolationCode
                                  ORDER BY Count DESC")
head(violationCodes2015, 5)
# ViolationCode      Count                                                         
#       21        1,469,228
#       38        1,305,007
#       14          908,418
#       36          747,098
#       37          735,600

violationCodes2015_top5 <- data.frame(head(violationCodes2015,5))

ggplot(violationCodes2015_top5, aes(x=reorder(ViolationCode,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Violation Code", y = "Count", title = "Frequency of the top five violation codes in 2015") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

violationCodes2016 <- SparkR::sql("SELECT ViolationCode, Count(ViolationCode) AS Count
                                  FROM data_2016_tbl
                                  GROUP BY ViolationCode
                                  ORDER BY Count DESC")
head(violationCodes2016, 5)
# ViolationCode    Count                                                         
#      21        1,497,269
#      36        1,232,952
#      38        1,126,835
#      14          860,045
#      37          677,805

violationCodes2016_top5 <- data.frame(head(violationCodes2016,5))

ggplot(violationCodes2016_top5, aes(x=reorder(ViolationCode,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Violation Code", y = "Count", title = "Frequency of the top five violation codes in 2016") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

violationCodes2017 <- SparkR::sql("SELECT ViolationCode, Count(ViolationCode) AS Count
                                  FROM data_2017_tbl
                                  GROUP BY ViolationCode
                                  ORDER BY Count DESC")
head(violationCodes2017, 5)
# ViolationCode   Count                                                         
#      21       1,500,396
#      36       1,345,237
#      38       1,050,418
#      14         880,152
#      20         609,231

violationCodes2017_top5 <- data.frame(head(violationCodes2017,5))

ggplot(violationCodes2017_top5, aes(x=reorder(ViolationCode,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Violation Code", y = "Count", title = "Frequency of the top five violation codes in 2017") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

violationCodes2015_top5$Year <- c(2015,2015,2015,2015,2015)
violationCodes2016_top5$Year <- c(2016,2016,2016,2016,2016)
violationCodes2017_top5$Year <- c(2017,2017,2017,2017,2017)

violationCodescombined <- rbind(violationCodes2015_top5,violationCodes2016_top5,violationCodes2017_top5)

ggplot(violationCodescombined, aes(x=reorder(ViolationCode,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') + facet_wrap(~Year) +
  labs(x = "Violation Code", y = "Count", title = "Frequency of the top five violation codes by Year") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

#####################################################################################

# 2a) How often does each 'vehicle body type' get a parking ticket?
bodyType2015 <- SparkR::sql("SELECT VehicleBodyType, Count(VehicleBodyType) AS Count
                            FROM data_2015_tbl
                            GROUP BY VehicleBodyType
                            ORDER BY Count DESC")
head(bodyType2015, 5)
# VehicleBodyType   Count                                                       
#      SUBN       3,341,110
#      4DSD       3,001,810
#       VAN       1,570,227
#      DELV         822,040
#       SDN         428,571

bodyType2015_top5 <- data.frame(head(bodyType2015,5))

ggplot(bodyType2015_top5, aes(x=reorder(VehicleBodyType,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Vehicle Body Type", y = "Count", title = "Frequency of the top five Vehicle Body Type in 2015") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

bodyType2016 <- SparkR::sql("SELECT VehicleBodyType, Count(VehicleBodyType) AS Count
                            FROM data_2016_tbl
                            GROUP BY VehicleBodyType
                            ORDER BY Count DESC")
head(bodyType2016, 5)
# VehicleBodyType   Count                                                       
#       SUBN      3,393,838
#       4DSD      2,936,729
#        VAN      1,489,924
#       DELV        738,747
#        SDN        401,750

bodyType2016_top5 <- data.frame(head(bodyType2016,5))

ggplot(bodyType2016_top5, aes(x=reorder(VehicleBodyType,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Vehicle Body Type", y = "Count", title = "Frequency of the top five Vehicle Body Type in 2016") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

bodyType2017 <- SparkR::sql("SELECT VehicleBodyType, Count(VehicleBodyType) AS Count
                            FROM data_2017_tbl
                            GROUP BY VehicleBodyType
                            ORDER BY Count DESC")
head(bodyType2017, 5)
# VehicleBodyType   Count                                                       
#       SUBN      3,632,003
#       4DSD      3,017,372
#        VAN      1,384,121
#       DELV        672,123
#        SDN        414,984

bodyType2017_top5<- data.frame(head(bodyType2017,5))

ggplot(bodyType2017_top5, aes(x=reorder(VehicleBodyType,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Vehicle Body Type", y = "Count", title = "Frequency of the top five Vehicle Body Type in 2017") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# combining all years for comparision
bodyType2015_top5$Year <- c(2015,2015,2015,2015,2015)
bodyType2016_top5$Year <- c(2016,2016,2016,2016,2016)
bodyType2017_top5$Year <- c(2017,2017,2017,2017,2017)

bodyTypecombined_top5 <- rbind(bodyType2015_top5,bodyType2016_top5,bodyType2017_top5)

ggplot(bodyTypecombined_top5, aes(x=reorder(VehicleBodyType,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') + facet_wrap(~Year) +
  labs(x = "Vehicle Body Type", y = "Count", title = "Number of Tickets of top 5 Vehicle Body Type by Year") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

#####################################################################################

# 2b) How about the 'vehicle make'?
make2015 <- SparkR::sql("SELECT VehicleMake, Count(VehicleMake) AS Count
                        FROM data_2015_tbl
                        GROUP BY VehicleMake
                        ORDER BY Count DESC")
head(make2015, 5)
# VehicleMake   Count                                                           
#     FORD    1,373,157
#    TOYOT    1,082,206
#    HONDA      982,130
#    CHEVR      811,659
#    NISSA      805,572

make2015_top5<- data.frame(head(make2015,5))

ggplot(make2015_top5, aes(x=reorder(VehicleMake,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Vehicle Make", y = "Count", title = "Frequency of the top five Vehicle Make in 2015") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

make2016 <- SparkR::sql("SELECT VehicleMake, Count(VehicleMake) AS Count
                        FROM data_2016_tbl
                        GROUP BY VehicleMake
                        ORDER BY Count DESC")
head(make2016, 5)
# VehicleMake   Count                                                           
#     FORD    1,297,363
#    TOYOT    1,128,909
#    HONDA      991,735
#    NISSA      815,963
#    CHEVR      743,416

make2016_top5<- data.frame(head(make2016,5))

ggplot(make2016_top5, aes(x=reorder(VehicleMake,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Vehicle Make", y = "Count", title = "Frequency of the top five Vehicle Make in 2016") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

make2017 <- SparkR::sql("SELECT VehicleMake, Count(VehicleMake) AS Count
                        FROM data_2017_tbl
                        GROUP BY VehicleMake
                        ORDER BY Count DESC")
head(make2017, 5)
# VehicleMake   Count                                                           
#     FORD    1,250,777
#    TOYOT    1,179,265
#    HONDA    1,052,006
#    NISSA      895,225
#    CHEVR      698,024

make2017_top5<- data.frame(head(make2017,5))

ggplot(make2017_top5, aes(x=reorder(VehicleMake,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Vehicle Make", y = "Count", title = "Frequency of the top five Vehicle Make in 2017") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# combining all years for comparision
make2015_top5$Year <- c(2015,2015,2015,2015,2015)
make2016_top5$Year <- c(2016,2016,2016,2016,2016)
make2017_top5$Year <- c(2017,2017,2017,2017,2017)

makecombined_top5 <- rbind(make2015_top5,make2016_top5,make2017_top5)

ggplot(makecombined_top5, aes(x=reorder(VehicleMake,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') + facet_wrap(~Year) +
  labs(x = "Vehicle Make", y = "Count", title = "Number of Tickets of top 5 Vehicle Make by Year") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

#####################################################################################

# 3) A precinct is a police station that has a certain zone of the city under its
# command. Find the (5 highest) frequency of tickets for each of the following:

# 3a) 'Violation Precinct' (this is the precinct of the zone where the violation
# occurred).
vPrecinct2015 <- SparkR::sql("SELECT ViolationPrecinct,
                             Count(ViolationPrecinct) AS Count
                             FROM data_2015_tbl
                             GROUP BY ViolationPrecinct
                             ORDER BY Count DESC")
head(vPrecinct2015, 6)
# ViolationPrecinct   Count                                                     
#         0         1,455,166
#        19           550,797
#        18           393,802
#        14           377,750
#         1           302,737
#       114           295,855

vPrecinct2015_top5<- data.frame(head(vPrecinct2015,6))

ggplot(vPrecinct2015_top5, aes(x=reorder(ViolationPrecinct,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Violation Precinct", y = "Count", title = "Frequency of the top Six Violation Precinct in 2015") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

vPrecinct2016 <- SparkR::sql("SELECT ViolationPrecinct,
                             Count(ViolationPrecinct) AS Count
                             FROM data_2016_tbl
                             GROUP BY ViolationPrecinct
                             ORDER BY Count DESC")
head(vPrecinct2016, 6)
# ViolationPrecinct   Count                                                     
#         0         1,807,139
#        19           545,669
#        18           325,559
#        14           318,193
#         1           299,074
#       114           286,741

vPrecinct2016_top5<- data.frame(head(vPrecinct2016,6))

ggplot(vPrecinct2016_top5, aes(x=reorder(ViolationPrecinct,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Violation Precinct", y = "Count", title = "Frequency of the top Six Violation Precinct in 2016") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

vPrecinct2017 <- SparkR::sql("SELECT ViolationPrecinct,
                             Count(ViolationPrecinct) AS Count
                             FROM data_2017_tbl
                             GROUP BY ViolationPrecinct
                             ORDER BY Count DESC")
head(vPrecinct2017, 6)
# ViolationPrecinct   Count                                                     
#         0         1,950,083
#        19           528,317
#        14           347,736
#         1           326,961
#        18           302,008
#       114           292,682

vPrecinct2017_top5<- data.frame(head(vPrecinct2017,6))

ggplot(vPrecinct2017_top5, aes(x=reorder(ViolationPrecinct,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Violation Precinct", y = "Count", title = "Frequency of the top Six Violation Precinct in 2017") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# combining all years for comparision
vPrecinct2015_top5$Year <- c(2015,2015,2015,2015,2015,2015)
vPrecinct2016_top5$Year <- c(2016,2016,2016,2016,2016,2016)
vPrecinct2017_top5$Year <- c(2017,2017,2017,2017,2017,2017)

vPrecinctcombined_top5 <- rbind(vPrecinct2015_top5,vPrecinct2016_top5,vPrecinct2017_top5)

ggplot(vPrecinctcombined_top5, aes(x=reorder(ViolationPrecinct,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') + facet_wrap(~Year) +
  labs(x = "Violation Precinct", y = "Count", title = "Frequency of the top Six Violation Precinct by Year") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# Using this, can you make any insights for parking violations in any specific areas
# of the city?
# Tickets in all precincts fell from 2015 to 2016. Between 2016 and 2017 the number of
# tickets increased in precincts 14, 1, and 114 and fell in precincts 19, and 18.
# Overall between 2015 and 2017 the number of tickets increased in precinct 1 only.

#####################################################################################

# 3b) 'Issuer Precinct' (this is the precinct that issued the ticket)
iPrecinct2015 <- SparkR::sql("SELECT IssuerPrecinct, Count(IssuerPrecinct) AS Count
                             FROM data_2015_tbl
                             GROUP BY IssuerPrecinct
                             ORDER BY Count DESC")
head(iPrecinct2015, 6)
# IssuerPrecinct      Count                                                        
#        0        1,648,671
#       19          536,627
#       18          384,863
#       14          363,734
#        1          293,942
#      114          291,100

iPrecinct2015_top5<- data.frame(head(iPrecinct2015,6))

ggplot(iPrecinct2015_top5, aes(x=reorder(IssuerPrecinct,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Issuer Precinct", y = "Count", title = "Frequency of the top Six Issuer Precinct in 2015") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

iPrecinct2016 <- SparkR::sql("SELECT IssuerPrecinct, Count(IssuerPrecinct) AS Count
                             FROM data_2016_tbl
                             GROUP BY IssuerPrecinct
                             ORDER BY Count DESC")
head(iPrecinct2016, 6)
# IssuerPrecinct    Count                                                        
#        0      2,067,219
#       19        532,298
#       18        317,451
#       14        309,727
#        1        290,472
#      114        282,493

iPrecinct2016_top5<- data.frame(head(iPrecinct2016,6))

ggplot(iPrecinct2016_top5, aes(x=reorder(IssuerPrecinct,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Issuer Precinct", y = "Count", title = "Frequency of the top Six Issuer Precinct in 2016") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")


iPrecinct2017 <- SparkR::sql("SELECT IssuerPrecinct, Count(IssuerPrecinct) AS Count
                             FROM data_2017_tbl
                             GROUP BY IssuerPrecinct
                             ORDER BY Count DESC")
head(iPrecinct2017, 6)
# IssuerPrecinct      Count                                                        
#        0        2,255,086
#       19          514,786
#       14          340,862
#        1          316,776
#       18          292,237
#      114          286,316

iPrecinct2017_top5<- data.frame(head(iPrecinct2017,6))

ggplot(iPrecinct2017_top5, aes(x=reorder(IssuerPrecinct,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Issuer Precinct", y = "Count", title = "Frequency of the top Six Issuer Precinct in 2017") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# combining all years for comparision
iPrecinct2015_top5$Year <- c(2015,2015,2015,2015,2015,2015)
iPrecinct2016_top5$Year <- c(2016,2016,2016,2016,2016,2016)
iPrecinct2017_top5$Year <- c(2017,2017,2017,2017,2017,2017)

iPrecinctcombined_top5 <- rbind(iPrecinct2015_top5,iPrecinct2016_top5,iPrecinct2017_top5)

ggplot(iPrecinctcombined_top5, aes(x=reorder(IssuerPrecinct,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') + facet_wrap(~Year) +
  labs(x = "Issuer Precinct", y = "Count", title = "Frequency of the top Six Issuer Precinct by Year") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

#####################################################################################

# 4) Find the violation code frequency across three precincts which have issued the
# most number of tickets - do these precinct zones have an exceptionally high frequency
# of certain violation codes? Are these codes common across precincts?

# Across the three years, the precincts that have issued the most tickets are:
# We are not considering Precinct 0 as they are considered invalid entries, 
# So we will consider next top 3 entries as valid entries which are common across all the three years.
# 1. Precinct 19 (1,642,080 tickets)
# 2. Precinct 14 (1,053,210 tickets)
# 3. Precinct 18 (1,037,014 tickets)

# Top 10 Violation codes by issuer Precinct in 2015

precinct_2015 <- SparkR::sql("SELECT IssuerPrecinct,
                             ViolationCode,
                             Count
                             FROM (SELECT IssuerPrecinct,
                             ViolationCode,
                             Count,
                             dense_rank() over (partition by IssuerPrecinct order by Count desc) Rnk
                             FROM (SELECT IssuerPrecinct,ViolationCode, COUNT (ViolationCode) AS Count
                             FROM data_2015_tbl where IssuerPrecinct in (14,18,19)
                             GROUP BY IssuerPrecinct, ViolationCode))
                             WHERE Rnk <= 10 order by IssuerPrecinct, Count DESC")

head(precinct_2015,30)

df_precinct_2015 <- data.frame(head(precinct_2015,nrow(precinct_2015)))


# Plot the data.
ggplot(df_precinct_2015, aes(x=as.factor(ViolationCode), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') + facet_grid(~IssuerPrecinct) + 
  labs(x = "Violation Code", y = "Ticket Count", title = "Top 10 Violation codes Tickets Issued by Issuer Precincts 14, 18 and 19 in 2015 ") +
  geom_text(aes(label=Count),vjust=0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# In 2015, precincts 14 and 18 both have violation codes 14 and 69 as the most
# frequent. Violation codes 37 and 38 are most common in precinct 19. 

#Overall top 3 :
vcodes2015 <- SparkR::sql("SELECT IssuerPrecinct,
                          ViolationCode,
                          Count
                          FROM (SELECT IssuerPrecinct,
                          ViolationCode,
                          Count,
                          dense_rank() over (partition by IssuerPrecinct order by Count desc) Rnk
                          FROM (SELECT IssuerPrecinct,ViolationCode, COUNT (ViolationCode) AS Count
                          FROM data_2015_tbl where IssuerPrecinct in (14,18,19)
                          GROUP BY IssuerPrecinct, ViolationCode))
                          WHERE Rnk <= 3 order by IssuerPrecinct, Count DESC")

head(vcodes2015, 12)

df_vcodes2015 <- data.frame(head(vcodes2015, nrow(vcodes2015)))

# Plot the data.
ggplot(df_vcodes2015, aes(x=as.factor(ViolationCode), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') + facet_grid(~IssuerPrecinct) + 
  labs(x = "Violation Code", y = "Ticket Count", title = "Tickets Issued by Top 3 Issuer Precincts 14, 18 and 19 in 2015") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")


# Issuer Precinct     Violation Code       Count
#       14                  69            79,330
#       14                  14            75,985
#       14                  31            40,410
#       18                  14           119,078
#       18                  69            56,436
#       18                  31            30,030
#       19                  38            89,102
#       19                  37            78,716
#       19                  14            59,915

# Overall totals across the top three preincts in 2015.
vcodeTotals_2015 <- SparkR::sql("SELECT ViolationCode, COUNT(ViolationCode) AS Count
                                FROM data_2015_tbl
                                WHERE IssuerPrecinct in (14,18,19)
                                GROUP BY ViolationCode
                                ORDER BY Count DESC")
head(vcodeTotals_2015, 5)
#   ViolationCode   Count                                                          
#            14   254,978
#            69   140,479
#            38   114,163
#            37    90,571
#            31    72,703

##Repeating for 2016

# Top 10 Violation codes by issuer Precinct in 2016

precinct_2016 <- SparkR::sql("SELECT IssuerPrecinct,
                             ViolationCode,
                             Count
                             FROM (SELECT IssuerPrecinct,
                             ViolationCode,
                             Count,
                             dense_rank() over (partition by IssuerPrecinct order by Count desc) Rnk
                             FROM (SELECT IssuerPrecinct,ViolationCode, COUNT (ViolationCode) AS Count
                             FROM data_2016_tbl where IssuerPrecinct in (14,18,19)
                             GROUP BY IssuerPrecinct, ViolationCode))
                             WHERE Rnk <= 10 order by IssuerPrecinct, Count DESC")

head(precinct_2016,30)

df_precinct_2016 <- data.frame(head(precinct_2016,nrow(precinct_2016)))

# Plot the data.
ggplot(df_precinct_2016, aes(x=as.factor(ViolationCode), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') + facet_grid(~IssuerPrecinct) + 
  labs(x = "Violation Code", y = "Ticket Count", title = "Top 10 Violation codes Tickets Issued by Issuer Precincts 14, 18 and 19 in 2016 ") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")


# In 2016, precincts 14 and 18 both have violation codes 14 and 69 as the most
# frequent. Violation codes 37 and 38 are most common in precinct 19. 

#Overall top 3 :
vcodes2016 <- SparkR::sql("SELECT IssuerPrecinct,
                          ViolationCode,
                          Count
                          FROM (SELECT IssuerPrecinct,
                          ViolationCode,
                          Count,
                          dense_rank() over (partition by IssuerPrecinct order by Count desc) Rnk
                          FROM (SELECT IssuerPrecinct,ViolationCode, COUNT (ViolationCode) AS Count
                          FROM data_2016_tbl where IssuerPrecinct in (14,18,19)
                          GROUP BY IssuerPrecinct, ViolationCode))
                          WHERE Rnk <= 3 order by IssuerPrecinct, Count DESC")

head(vcodes2016, 10)

#  IssuerPrecinct ViolationCode  Count                                            
#             14            69  66,874
#             14            14  61,358
#             14            31  35,169
#             18            14  98,160
#             18            69  47,129
#             18            47  23,618
#             19            38  76,178
#             19            37  74,758
#             19            46  71,509

df_vcodes2016 <- data.frame(head(vcodes2016, nrow(vcodes2016)))

# Plot the data.
ggplot(df_vcodes2016, aes(x=as.factor(ViolationCode), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') + facet_grid(~IssuerPrecinct) + 
  labs(x = "Violation Code", y = "Ticket Count", title = "Tickets Issued by Top 3 Issuer Precincts 14, 18 and 19 in 2016") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")


# Overall totals across the top three preincts in 2016.
vcodeTotals_2016 <- SparkR::sql("SELECT ViolationCode, COUNT(ViolationCode) AS Count
                                FROM data_2016_tbl
                                WHERE IssuerPrecinct = 14 OR IssuerPrecinct = 18 OR
                                IssuerPrecinct = 19
                                GROUP BY ViolationCode
                                ORDER BY Count DESC")
head(vcodeTotals_2016, 5)
#   ViolationCode   Count                                                          
#            14   220,374
#            69   117,993
#            46    95,873
#            38    95,828
#            37    84,986

# Repeating for 2017

# Top 10 Violation codes by issuer Precinct in 2017

precinct_2017 <- SparkR::sql("SELECT IssuerPrecinct,
                             ViolationCode,
                             Count
                             FROM (SELECT IssuerPrecinct,
                             ViolationCode,
                             Count,
                             dense_rank() over (partition by IssuerPrecinct order by Count desc) Rnk
                             FROM (SELECT IssuerPrecinct,ViolationCode, COUNT (ViolationCode) AS Count
                             FROM data_2017_tbl where IssuerPrecinct in (14,18,19)
                             GROUP BY IssuerPrecinct, ViolationCode))
                             WHERE Rnk <= 10 order by IssuerPrecinct, Count DESC")

head(precinct_2017,30)

df_precinct_2017 <- data.frame(head(precinct_2017,nrow(precinct_2017)))

# Plot the data.
ggplot(df_precinct_2017, aes(x=as.factor(ViolationCode), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') + facet_grid(~IssuerPrecinct) + 
  labs(x = "Violation Code", y = "Ticket Count", title = "Top 10 Violation codes Tickets Issued by Issuer Precincts 14, 18 and 19 in 2017 ") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")


# In 2017, precincts 14 and 18 both have violation codes 14 and 69 as the most
# frequent. Violation codes 46 and 37 are most common in precinct 19. 

# Overall top 3 :
vcodes2017 <- SparkR::sql("SELECT IssuerPrecinct,
                          ViolationCode,
                          Count
                          FROM (SELECT IssuerPrecinct,
                          ViolationCode,
                          Count,
                          dense_rank() over (partition by IssuerPrecinct order by Count desc) Rnk
                          FROM (SELECT IssuerPrecinct,ViolationCode, COUNT (ViolationCode) AS Count
                          FROM data_2017_tbl where IssuerPrecinct in (14,18,19)
                          GROUP BY IssuerPrecinct, ViolationCode))
                          WHERE Rnk <= 3 order by IssuerPrecinct, Count DESC")

head(vcodes2017, 10)

df_vcodes2017 <- data.frame(head(vcodes2017, nrow(vcodes2017)))

# Plot the data.
ggplot(df_vcodes2017, aes(x=as.factor(ViolationCode), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') + facet_grid(~IssuerPrecinct) + 
  labs(x = "Violation Code", y = "Ticket Count", title = "Tickets Issued by Top 3 Issuer Precincts 14, 18 and 19 in 2017") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")


# Issuer Precinct     Violation Code       Count
#             14            14            73,007
#             14            69            57,316
#             14            31            39,430
#             18            14            90,145
#             18            69            36,246
#             18            47            23,487
#             19            46            84,789
#             19            38            71,631
#             19            37            71,592

# Overall totals across the top three preincts in 2017.
vcodeTotals_2017 <- SparkR::sql("SELECT ViolationCode, COUNT(ViolationCode) AS Count
                                FROM data_2017_tbl
                                WHERE IssuerPrecinct = 14 OR IssuerPrecinct = 18 OR
                                IssuerPrecinct = 19
                                GROUP BY ViolationCode
                                ORDER BY Count DESC")
head(vcodeTotals_2017, 5)
#   ViolationCode   Count                                                          
#            14    220,025
#            46    112,223
#            69     98,044
#            38     89,000
#            37     78,863



# Comparative  analysis using Union All of all the three datasets 2015, 2016 and 2017

precinct <- SparkR::sql("SELECT IssuerPrecinct,
                        ViolationCode,
                        Count, Year
                        from ((SELECT IssuerPrecinct,
                        ViolationCode,
                        Count,2015 as Year
                        FROM (SELECT IssuerPrecinct,
                        ViolationCode,
                        Count,
                        dense_rank() over (partition by IssuerPrecinct order by Count desc) Rnk
                        FROM (SELECT IssuerPrecinct,ViolationCode, COUNT (ViolationCode) AS Count
                        FROM data_2015_tbl where IssuerPrecinct in (14,18,19)
                        GROUP BY IssuerPrecinct, ViolationCode))
                        WHERE Rnk <= 3 order by IssuerPrecinct, Count DESC)
                        UNION ALL
                        (SELECT IssuerPrecinct,
                        ViolationCode,
                        Count,2016 as Year
                        FROM (SELECT IssuerPrecinct,
                        ViolationCode,
                        Count,
                        dense_rank() over (partition by IssuerPrecinct order by Count desc) Rnk
                        FROM (SELECT IssuerPrecinct,ViolationCode, COUNT (ViolationCode) AS Count
                        FROM data_2016_tbl where IssuerPrecinct in (14,18,19)
                        GROUP BY IssuerPrecinct, ViolationCode))
                        WHERE Rnk <= 3 order by IssuerPrecinct, Count DESC)
                        UNION ALL
                        (SELECT IssuerPrecinct,
                        ViolationCode,
                        Count,2017 as Year
                        FROM (SELECT IssuerPrecinct,
                        ViolationCode,
                        Count,
                        dense_rank() over (partition by IssuerPrecinct order by Count desc) Rnk
                        FROM (SELECT IssuerPrecinct,ViolationCode, COUNT (ViolationCode) AS Count
                        FROM data_2017_tbl where IssuerPrecinct in (14,18,19)
                        GROUP BY IssuerPrecinct, ViolationCode))
                        WHERE Rnk <= 3 order by IssuerPrecinct, Count DESC))")


head(precinct,30)

df_precinct <- data.frame(head(precinct,nrow(precinct)))

# Plot the data.
ggplot(df_precinct, aes(x=as.factor(ViolationCode), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') + facet_grid(~Year~IssuerPrecinct)  + 
  labs(x = "Violation Code", y = "Ticket Count", title = "Top 3 Violation codes Tickets Issued by Issuer Precincts 14, 18 and 19 in 2015, 2016 and 2017 ") +
  geom_text(aes(label=Count),vjust=0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# Issuer precincts 14 and 18 both have violation codes 14 and 69 as the most frequent violation across all the years. 
# Issuer precinct 19 has violation codes 37 and 38 as the most frequent Violations across all the years.


#####################################################################################

# 5) You want to find out the properties of parking violations across different
# times of the day:

# 5a) Find a way to deal with missing values, if any.
nrow(data_2015) # Total of 10,598,035 tickets in 2015.

vTime2015 <- SparkR::sql("SELECT COUNT(*) AS NullViolationTimeCount
                         FROM data_2015_tbl
                         WHERE ViolationTime IS NULL")
head(vTime2015)
# In 2015, 1438 tickets had NULL Violation Time - problem statement advises dropping
# rows with NULL. This should leave 10,598,035 - 1438 = 10,596,597 tickets.

data_2015 <- dropna(data_2015, cols = c("ViolationTime"))
nrow(data_2015) # Total of 10,596,597 tickets remain in 2015.

# Update the SQL views for further analysis.
createOrReplaceTempView(data_2015, "data_2015_tbl")

nrow(data_2016) # Total of 10,396,894 tickets issued in 2016.

vTime2016 <- SparkR::sql("SELECT COUNT(*) AS NullViolationTimeCount
                         FROM data_2016_tbl
                         WHERE ViolationTime IS NULL")
head(vTime2016)
# In 2016, 716 tickets had NULL Violation Time, dropping them should leave
# 10396894 - 716 = 10,396,178 tickets.

data_2016 <- dropna(data_2016, cols = c("ViolationTime"))
nrow(data_2016) # Total of 10,396,178 tickets remain in 2016 after NULLs dropped.

# Update the SQL views for further analysis.
createOrReplaceTempView(data_2016, "data_2016_tbl")

nrow(data_2017) # Total of 10,539,563 tickets issued in 2016.

vTime2017 <- SparkR::sql("SELECT COUNT(*) AS NullViolationTimeCount
                         FROM data_2017_tbl
                         WHERE ViolationTime IS NULL")
head(vTime2017)
# In 2017, 53 tickets had NULL Violation Time, dropping them should leave
# 10,539,563 - 53 = 10,539,510 tickets.

data_2017 <- dropna(data_2017, cols = c("ViolationTime"))
nrow(data_2017) # Total of 10,539,510 tickets remain in 2017 after NULLs dropped.

# Update the SQL views for further analysis.
createOrReplaceTempView(data_2017, "data_2017_tbl")

#####################################################################################

# 5b) The Violation Time field is specified in a strange format. Find a way to make
# this into a time attribute that you can use to divide into groups.

# Examine the first 50 rows to identify the pattern in the Violation Time column.
vTime2015 <- SparkR::sql("SELECT ViolationTime FROM data_2015_tbl")
head(vTime2015, 50)

# ViolationTime column is in the format "HHMM" followed by "A" for AM or "P" for PM.
# Convert this into format such as: HH:MM AM. To use concat() function we need a
# column of all characters that we want to concatenate, so add a column with ":" and
# "M" characters.
data_2015$temp_M <- "M"
data_2015$temp_colon <- ":"

# Since we have the AM/PM suffix, it is unnecessary to differentiate between hours 00
# and 12, so replace all 00 hours with 12. Separate hours into a new column.
data_2015$violation_Hr <- substr(data_2015$ViolationTime, 1, 2)

# Replace "00" in temp_Hr column with "12"
data_2015$violation_Hr <- regexp_replace(x = data_2015$violation_Hr, pattern = "00",
                                         replacement = "12")

# Use temporary column to convert ViolationTime to format HH:MM followed by AM/PM.
data_2015$temp <- concat(data_2015$violation_Hr,
                         data_2015$temp_colon,
                         substr(data_2015$ViolationTime, 3, 4),
                         substr(data_2015$ViolationTime, 5, 5),
                         data_2015$temp_M)

# Converting ViolationTime to TimeStamp format
data_2015$ViolationTS <- to_timestamp(x = data_2015$temp, format = "hh:mma")

# Check is any rows were converted to NULL.
createOrReplaceTempView(data_2015, "data_2015_tbl")
nullViolTS2015 <- SparkR::sql("SELECT ViolationTS, ViolationTime
                              FROM data_2015_tbl
                              WHERE ViolationTS IS NULL")
nrow(nullViolTS2015) # 229 rows have NULL timestamp.
head(nullViolTS2015)
# NULL timestamps came from non-sensical ViolationTimes such as "09+4A" which cannot
# be easily imouted. We can delete these rows since there are not many.

data_2015 <- dropna(data_2015, cols = c("ViolationTS"))

# Drop the temporary columns, keep violation_Hr for further analysis.
data_2015 <- drop(data_2015, c("temp_colon", "temp_M", "temp", "violation_Hr"))

# Update the SQL views for further analysis.
createOrReplaceTempView(data_2015, "data_2015_tbl")

# Repeat for 2016 
data_2016$temp_M <- "M"
data_2016$temp_colon <- ":"
data_2016$violation_Hr <- substr(data_2016$ViolationTime, 1, 2)
data_2016$violation_Hr <- regexp_replace(x = data_2016$violation_Hr, pattern = "00",
                                         replacement = "12")
data_2016$temp <- concat(data_2016$violation_Hr,
                         data_2016$temp_colon,
                         substr(data_2016$ViolationTime, 3, 4),
                         substr(data_2016$ViolationTime, 5, 5),
                         data_2016$temp_M)
data_2016$ViolationTS <- to_timestamp(x = data_2016$temp, format = "hh:mma")
data_2016 <- dropna(data_2016, cols = c("ViolationTS"))
data_2016 <- drop(data_2016, c("temp_colon", "temp_M", "temp", "violation_Hr"))
createOrReplaceTempView(data_2016, "data_2016_tbl")
# Repeat for 2017.
data_2017$temp_M <- "M"
data_2017$temp_colon <- ":"
data_2017$violation_Hr <- substr(data_2017$ViolationTime, 1, 2)
data_2017$violation_Hr <- regexp_replace(x = data_2017$violation_Hr, pattern = "00",
                                         replacement = "12")
data_2017$temp <- concat(data_2017$violation_Hr,
                         data_2017$temp_colon,
                         substr(data_2017$ViolationTime, 3, 4),
                         substr(data_2017$ViolationTime, 5, 5),
                         data_2017$temp_M)
data_2017$ViolationTS <- to_timestamp(x = data_2017$temp, format = "hh:mma")
data_2017 <- dropna(data_2017, cols = c("ViolationTS"))
data_2017 <- drop(data_2017, c("temp_colon", "temp_M", "temp", "violation_Hr"))
createOrReplaceTempView(data_2017, "data_2017_tbl")
#####################################################################################

# 5c) Divide 24 hours into six equal discrete bins of time. The intervals you choose
# are at your discretion. For each of these groups, find the three most commonly
# occurring violations.

# Extract hour from ViolationTime and use it to create new TimeBin column in 2015 data.
data_2015$violation_Hr <- hour(cast(data_2015$ViolationTS, dataType = "string"))
createOrReplaceTempView(data_2015, "data_2015_tbl")

timeBins2015 <- SparkR::sql("SELECT TimeBin,
                            ViolationCode,
                            Count
                            FROM (SELECT TimeBin,
                            ViolationCode,
                            Count,
                            dense_rank() over (partition by TimeBin order by Count desc) Rnk
                            FROM (SELECT ViolationCode, COUNT (ViolationCode) AS Count,
                            CASE
                            WHEN violation_Hr >= 0 AND violation_Hr <= 4 THEN '1.[0-4]'
                            WHEN violation_Hr > 4 AND violation_Hr <= 8 THEN '2.[4-8]'
                            WHEN violation_Hr > 8 AND violation_Hr <= 12 THEN '3.[8-12]'
                            WHEN violation_Hr > 12 AND violation_Hr <= 16 THEN '4.[12-16]'
                            WHEN violation_Hr > 16 AND violation_Hr <= 20 THEN '5.[16-20]'
                            WHEN violation_Hr > 20 AND violation_Hr < 24 THEN '6.[20-24]'
                            END AS TimeBin
                            FROM data_2015_tbl
                            GROUP BY TimeBin, ViolationCode))
                            WHERE Rnk <= 3 order by TimeBin, Count DESC")

nrow(timeBins2015)
head(timeBins2015, 18)

df_timeBins2015 <- data.frame(head(timeBins2015, 18))

# Plot the data.
ggplot(df_timeBins2015, aes(x=as.factor(ViolationCode), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  facet_grid(~TimeBin) + 
  labs(x = "Violation Code", y = "Ticket Count", title = "Tickets Issued by top 3 Violation Code in 2015 - Time Bin") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# Top three violation codes for each time bin in 2015:
######################################################
#    TimeBin ViolationCode     Count
#    1.[0-4]      21          66,945 
#    1.[0-4]      40          45,782 
#    1.[0-4]      78          41,081
#    2.[4-8]      21          470,149
#    2.[4-8]      14          203,254
#    2.[4-8]      20          124,541
#    3.[8-12]     21          926,708
#    3.[8-12]     38          508,749
#    3.[8-12]     36          386,238
#    4.[12-16]    38          534,735
#    4.[12-16]    37          405,454
#    4.[12-16]    14          284,515
#    5.[16-20]    38          155,790
#    5.[16-20]     7          122,958
#    5.[16-20]    37           98,028
#    6.[20-24]     7           48,129
#    6.[20-24]    38           34,338
#    6.[20-24]    14           33,672

# Repeat the steps for 2016.
data_2016$violation_Hr <- hour(cast(data_2016$ViolationTS, dataType = "string"))
createOrReplaceTempView(data_2016, "data_2016_tbl")

timeBins2016 <- SparkR::sql("SELECT TimeBin,
                            ViolationCode,
                            Count
                            FROM (SELECT TimeBin,
                            ViolationCode,
                            Count,
                            dense_rank() over (partition by TimeBin order by Count desc) Rnk
                            FROM (SELECT ViolationCode, COUNT (ViolationCode) AS Count,
                            CASE
                            WHEN violation_Hr >= 0 AND violation_Hr <= 4 THEN '1.[0-4]'
                            WHEN violation_Hr > 4 AND violation_Hr <= 8 THEN '2.[4-8]'
                            WHEN violation_Hr > 8 AND violation_Hr <= 12 THEN '3.[8-12]'
                            WHEN violation_Hr > 12 AND violation_Hr <= 16 THEN '4.[12-16]'
                            WHEN violation_Hr > 16 AND violation_Hr <= 20 THEN '5.[16-20]'
                            WHEN violation_Hr > 20 AND violation_Hr < 24 THEN '6.[20-24]'
                            END AS TimeBin
                            FROM data_2016_tbl
                            GROUP BY TimeBin, ViolationCode))
                            WHERE Rnk <= 3 order by TimeBin, Count DESC")
nrow(timeBins2016)
head(timeBins2016, 18)

df_timeBins2016 <- data.frame(head(timeBins2016, 18))

# Plot the data.
ggplot(df_timeBins2016, aes(x=as.factor(ViolationCode), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  facet_grid(~TimeBin) + 
  labs(x = "Violation Code", y = "Ticket Count", title = "Tickets Issued by top 3 Violation Code in 2016 - Timebin") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# Top three violation codes for each time bin in 2016:
######################################################
#   TimeBin     ViolationCode    Count                                               
#    1.[0-4]            21      71,584
#    1.[0-4]            40      45,121
#    1.[0-4]            78      33,983
#    2.[4-8]            21     489,466
#    2.[4-8]            14     204,944
#    2.[4-8]            36     189,130
#    3.[8-12]           21     931,596
#    3.[8-12]           36     630,732
#    3.[8-12]           38     444,361
#    4.[12-16]          38     456,669
#    4.[12-16]          36     400,267
#    4.[12-16]          37     373,039
#    5.[16-20]          38     135,471
#    5.[16-20]           7      98,834
#    5.[16-20]          37      88,334
#    6.[20-24]           7      38,990
#    6.[20-24]          40      33,679
#    6.[20-24]          14      32,289

# Repeat the steps for 2017.
data_2017$violation_Hr <- hour(cast(data_2017$ViolationTS, dataType = "string"))
createOrReplaceTempView(data_2017, "data_2017_tbl")

timeBins2017 <- SparkR::sql("SELECT TimeBin,
                            ViolationCode,
                            Count
                            FROM (SELECT TimeBin,
                            ViolationCode,
                            Count,
                            dense_rank() over (partition by TimeBin order by Count desc) Rnk
                            FROM (SELECT ViolationCode, COUNT (ViolationCode) AS Count,
                            CASE
                            WHEN violation_Hr >= 0 AND violation_Hr <= 4 THEN '1.[0-4]'
                            WHEN violation_Hr > 4 AND violation_Hr <= 8 THEN '2.[4-8]'
                            WHEN violation_Hr > 8 AND violation_Hr <= 12 THEN '3.[8-12]'
                            WHEN violation_Hr > 12 AND violation_Hr <= 16 THEN '4.[12-16]'
                            WHEN violation_Hr > 16 AND violation_Hr <= 20 THEN '5.[16-20]'
                            WHEN violation_Hr > 20 AND violation_Hr < 24 THEN '6.[20-24]'
                            END AS TimeBin
                            FROM data_2017_tbl
                            GROUP BY TimeBin, ViolationCode))
                            WHERE Rnk <= 3 order by TimeBin, Count DESC")
nrow(timeBins2017)
head(timeBins2017, 18)

df_timeBins2017 <- data.frame(head(timeBins2017, 18))

# Plot the data.
ggplot(df_timeBins2017, aes(x=as.factor(ViolationCode), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  facet_grid(~TimeBin) + 
  labs(x = "Violation Code", y = "Ticket Count", title = "Tickets Issued by top 3 Violation Code in 2017 - Time Bin") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")


# Top three violation codes for each time bin in 2017:
######################################################
#    TimeBin     ViolationCode      Count                                               
#    1.[0-4]            21         77,586
#    1.[0-4]            40         55,236
#    1.[0-4]            78         33,938
#    2.[4-8]            21        488,542
#    2.[4-8]            14        205,247
#    2.[4-8]            36        161,512
#    3.[8-12]           21        929,111
#    3.[8-12]           36        799,315
#    3.[8-12]           38        398,510
#    4.[12-16]          38        448,069
#    4.[12-16]          36        375,562
#    4.[12-16]          37        334,989
#    5.[16-20]          38        122,642
#    5.[16-20]           7        100,221
#    5.[16-20]          14         76,870
#    6.[20-24]           7         40,953
#    6.[20-24]          40         33,934
#    6.[20-24]          14         32,517

#####################################################################################

# 5d) Now, try another direction. For the 3 most commonly occurring violation codes,
# find the most common time of the day (in terms of the bins from the previous part).

# From aggregation task 1, we know that the top 3 violation codes in 2015 were 21, 38,
# and 14.
vcBins2015 <- SparkR::sql("SELECT ViolationCode,
                          CASE
                          WHEN violation_Hr >= 0 AND violation_Hr <= 4 THEN '1.[0-4]'
                          WHEN violation_Hr > 4 AND violation_Hr <= 8 THEN '2.[4-8]'
                          WHEN violation_Hr > 8 AND violation_Hr <= 12 THEN '3.[8-12]'
                          WHEN violation_Hr > 12 AND violation_Hr <= 16 THEN '4.[12-16]'
                          WHEN violation_Hr > 16 AND violation_Hr <= 20 THEN '5.[16-20]'
                          WHEN violation_Hr > 20 AND violation_Hr < 24 THEN '6.[20-24]'
                          END AS TimeBin,COUNT (ViolationCode) AS Count
                          FROM data_2015_tbl
                          WHERE ViolationCode in(21,38,14)
                          GROUP BY ViolationCode,TimeBin
                          ORDER BY 1,2,3 DESC")
head(vcBins2015, 18)

df_vcBins2015 <- data.frame(head(vcBins2015,nrow(vcBins2015)))

# Plot the data.
ggplot(df_vcBins2015, aes(x=TimeBin, y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  facet_grid(~ViolationCode) + 
  labs(x = "Time Bin", y = "Ticket Count", title = "Tickets Issued by top 3 Violation Code in 2015 - Time Bin") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# Frequency of Violation Code 14 tickets by time bin in 2015:
#############################################################
#     TimeBin      Count
#     1.[0-4]     31,309  tickets
#     2.[4-8]    203,254  tickets
#     3.[8-12]   278,902  tickets
#     4.[12-16]  284,515  tickets
#     5.[16-20]   76,747  tickets
#     6.[20-24]   33,672  tickets

# Frequency of Violation Code 21 tickets by time bin in 2015:
#############################################################

#     TimeBin      Count
#     1.[0-4]     66,945   tickets
#     2.[4-8]    470,149   tickets
#     3.[8-12]   926,708   tickets
#     4.[12-16]    4,400   tickets
#     5.[16-20]      573   tickets
#     6.[20-24]      414   tickets

# Frequency of Violation Code 38 tickets by time bin in 2015:
#############################################################

#     TimeBin       Count
#     1.[0-4]        716   tickets
#     2.[4-8]     70,679   tickets
#     3.[8-12]   508,749   tickets
#     4.[12-16]  534,735   tickets
#     5.[16-20]  155,790   tickets
#     6.[20-24]    34338   tickets

# From aggregation task 1, we know that the top 3 violation codes in 2016 were 21, 36,
# and 38.
vcBins2016 <- SparkR::sql("SELECT ViolationCode,
                          CASE
                          WHEN violation_Hr >= 0 AND violation_Hr <= 4 THEN '1.[0-4]'
                          WHEN violation_Hr > 4 AND violation_Hr <= 8 THEN '2.[4-8]'
                          WHEN violation_Hr > 8 AND violation_Hr <= 12 THEN '3.[8-12]'
                          WHEN violation_Hr > 12 AND violation_Hr <= 16 THEN '4.[12-16]'
                          WHEN violation_Hr > 16 AND violation_Hr <= 20 THEN '5.[16-20]'
                          WHEN violation_Hr > 20 AND violation_Hr < 24 THEN '6.[20-24]'
                          END AS TimeBin,COUNT (ViolationCode) AS Count
                          FROM data_2016_tbl
                          WHERE ViolationCode in(21,36,38)
                          GROUP BY ViolationCode,TimeBin
                          ORDER BY 1,2,3 DESC")
head(vcBins2016, 18)

df_vcBins2016 <- data.frame(head(vcBins2016,nrow(vcBins2016)))

# Plot the data.
ggplot(df_vcBins2016, aes(x=TimeBin, y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  facet_grid(~ViolationCode) + 
  labs(x = "Time Bin", y = "Ticket Count", title = "Tickets Issued by top 3 Violation Code in 2016 - Time Bin") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# Frequency of Violation Code 21 tickets by time bin in 2016:
#############################################################
#     TimeBin        Count
#     1.[0-4]       71,584  tickets
#     2.[4-8]      489,466  tickets
#     3.[8-12]     931,596  tickets
#     4.[12-16]      3,817  tickets
#     5.[16-20]        414  tickets
#     6.[20-24]        332  tickets

# Frequency of Violation Code 36 tickets by time bin in 2016:
#############################################################
#     TimeBin    Count
#     1.[0-4]           2  tickets
#     2.[4-8]     189,130  tickets
#     3.[8-12]    630,732  tickets
#     4.[12-16]   400,267  tickets
#     5.[16-20]    12,820  tickets
#     6.[20-24]        0   tickets

# Frequency of Violation Code 38 tickets by time bin in 2016:
#############################################################
#     TimeBin    Count
#     1.[0-4]        497   tickets
#     2.[4-8]     58,628   tickets
#     3.[8-12]   444,361   tickets
#     4.[12-16]  456,669   tickets
#     5.[16-20]  135,471   tickets
#     6.[20-24]   31,207   tickets


# From aggregation task 1, we know that the top 3 violation codes in 2017 were 21, 36,
# and 38.
vcBins2017 <- SparkR::sql("SELECT ViolationCode,
                          CASE
                          WHEN violation_Hr >= 0 AND violation_Hr <= 4 THEN '1.[0-4]'
                          WHEN violation_Hr > 4 AND violation_Hr <= 8 THEN '2.[4-8]'
                          WHEN violation_Hr > 8 AND violation_Hr <= 12 THEN '3.[8-12]'
                          WHEN violation_Hr > 12 AND violation_Hr <= 16 THEN '4.[12-16]'
                          WHEN violation_Hr > 16 AND violation_Hr <= 20 THEN '5.[16-20]'
                          WHEN violation_Hr > 20 AND violation_Hr < 24 THEN '6.[20-24]'
                          END AS TimeBin,COUNT (ViolationCode) AS Count
                          FROM data_2017_tbl
                          WHERE ViolationCode in(21,36,38)
                          GROUP BY ViolationCode,TimeBin
                          ORDER BY 1,2,3 DESC")
head(vcBins2017, 18)

df_vcBins2017 <- data.frame(head(vcBins2015,18))

# Plot the data.
ggplot(df_vcBins2017, aes(x=TimeBin, y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  facet_grid(~ViolationCode) + 
  labs(x = "Violation Code", y = "Ticket Count", title = "Tickets Issued by top 3 Violation Code in 2017 - Time Bin") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# Frequency of Violation Code 21 tickets by time bin in 2017:
#############################################################
#     TimeBin    Count
#     1.[0-4]       77,586 tickets
#     2.[4-8]      488,542 tickets
#     3.[8-12]     929,111 tickets
#     4.[12-16]      4,436 tickets
#     5.[16-20]        391 tickets
#     6.[20-24]        275 tickets

# Frequency of Violation Code 36 tickets by time bin in 2017:
#############################################################
#     TimeBin    Count
#     1.[0-4]           0 tickets
#     2.[4-8]     161,512 tickets
#     3.[8-12]    799,315 tickets
#     4.[12-16]   375,562 tickets
#     5.[16-20]     8,848 tickets
#     6.[20-24]         0 tickets

# Frequency of Violation Code 38 tickets by time bin in 2017:
#############################################################
#     TimeBin    Count
#     1.[0-4]        580 tickets
#     2.[4-8]     52,149 tickets
#     3.[8-12]   398,510 tickets
#     4.[12-16]  448,069 tickets
#     5.[16-20]  122,642 tickets
#     6.[20-24]   28,465 tickets

#####################################################################################

# 6) Lets try and find some seasonality in this data.

# 6a) First, divide the year into some number of seasons, and find frequencies of
# tickets for each season.

seasonBins2015 <- SparkR::sql("SELECT COUNT (ViolationCode) AS Count,
                              CASE
                              WHEN IssueMonth >= 3 AND IssueMonth < 6 THEN 'Spring'
                              WHEN IssueMonth >= 6 AND IssueMonth < 9 THEN 'Summer'
                              WHEN IssueMonth >= 9 AND IssueMonth < 12 THEN 'Autumn'
                              WHEN IssueMonth >= 12 OR IssueMonth < 3 THEN 'Winter'
                              END AS SeasonBin
                              FROM data_2015_tbl
                              GROUP BY SeasonBin
                              ORDER BY Count DESC")
head(seasonBins2015, 4)

df_seasonBins2015 <- data.frame(head(seasonBins2015,nrow(seasonBins2015)))

# Plot the data.
ggplot(df_seasonBins2015, aes(x=reorder(SeasonBin,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Season Bin", y = "Ticket Count", title = "Tickets Issued in 2015 - Season") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")


# Tickets by season in 2015.
############################
# Spring (March - May)            2,860,584 tickets
# Summer (June - August)          2,837,839 tickets
# Autumn (September - November)   2,718,051 tickets
# Winter (December - February)    2,179,894 tickets


# Repeat the same steps for 2016.

seasonBins2016 <- SparkR::sql("SELECT COUNT (ViolationCode) AS Count,
                              CASE
                              WHEN IssueMonth >= 3 AND IssueMonth < 6 THEN 'Spring'
                              WHEN IssueMonth >= 6 AND IssueMonth < 9 THEN 'Summer'
                              WHEN IssueMonth >= 9 AND IssueMonth < 12 THEN 'Autumn'
                              WHEN IssueMonth >= 12 OR IssueMonth < 3 THEN 'Winter'
                              END AS SeasonBin
                              FROM data_2016_tbl
                              GROUP BY SeasonBin
                              ORDER BY Count DESC")
head(seasonBins2016, 4)

df_seasonBins2016 <- data.frame(head(seasonBins2016,nrow(seasonBins2016)))

# Plot the data.
ggplot(df_seasonBins2016, aes(x=reorder(SeasonBin,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Season Bin", y = "Ticket Count", title = "Tickets Issued in 2016 - Season") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# Tickets by season in 2016.
############################
# Autumn (September - November)   2,971,213 tickets
# Spring (March - May)            2,788,921 tickets
# Winter (December - February)    2,421,449 tickets
# Summer (June - August)          2,214,285 tickets

# Repeat the same steps for 2017.
seasonBins2017 <- SparkR::sql("SELECT COUNT (ViolationCode) AS Count,
                              CASE
                              WHEN IssueMonth >= 3 AND IssueMonth < 6 THEN 'Spring'
                              WHEN IssueMonth >= 6 AND IssueMonth < 9 THEN 'Summer'
                              WHEN IssueMonth >= 9 AND IssueMonth < 12 THEN 'Autumn'
                              WHEN IssueMonth >= 12 OR IssueMonth < 3 THEN 'Winter'
                              END AS SeasonBin
                              FROM data_2017_tbl
                              GROUP BY SeasonBin
                              ORDER BY Count DESC")
head(seasonBins2017, 4)

df_seasonBins2017 <- data.frame(head(seasonBins2017,nrow(seasonBins2017)))

# Plot the data.
ggplot(df_seasonBins2017, aes(x=reorder(SeasonBin,-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "Season Bin", y = "Ticket Count", title = "Tickets Issued in 2017 - Season") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# Tickets by season in 2017.
############################
# Spring (March - May)            2,873,320 tickets
# Autumn (September - November)   2,829,155 tickets
# Winter (December - February)    2,482,995 tickets
# Summer (June - August)          2,353,862 tickets


# Comparative Analysis for all the years.
df_seasonBins2015$Year <- c(2015,2015,2015,2015)
df_seasonBins2016$Year <- c(2016,2016,2016,2016)
df_seasonBins2017$Year <- c(2017,2017,2017,2017)

df_seasonBinscombined <- rbind(df_seasonBins2015,df_seasonBins2016,df_seasonBins2017)
View(df_seasonBinscombined)

# Plot the data.

ggplot(df_seasonBinscombined, aes(x=SeasonBin, y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') + facet_wrap(~Year) +
  labs(x = "Season Bin", y = "Ticket Count", title = "Tickets Issued for each Season by Yearly") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

#####################################################################################

# 6b) Then, find the three most common violations for each of these seasons.
seasonBins2015 <- SparkR::sql("SELECT SeasonBin,
                              ViolationCode,
                              Count
                              FROM (SELECT SeasonBin,
                              ViolationCode,
                              Count,
                              dense_rank() over (partition by SeasonBin order by Count desc) Rnk
                              FROM (SELECT ViolationCode, COUNT (ViolationCode) AS Count,
                              CASE
                              WHEN IssueMonth >= 3 AND IssueMonth < 6 THEN 'Spring'
                              WHEN IssueMonth >= 6 AND IssueMonth < 9 THEN 'Summer'
                              WHEN IssueMonth >= 9 AND IssueMonth < 12 THEN 'Autumn'
                              WHEN IssueMonth >= 12 OR IssueMonth < 3 THEN 'Winter'
                              END AS SeasonBin
                              FROM data_2015_tbl
                              GROUP BY SeasonBin, ViolationCode))
                              WHERE Rnk <= 3
                              ORDER BY SeasonBin, Count DESC")
nrow(seasonBins2015)
head(seasonBins2015, 12)

df_seasonBins2015 <- data.frame(head(seasonBins2015,12))

# Plot the data.
ggplot(df_seasonBins2015, aes(x=as.factor(ViolationCode), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  facet_grid(~SeasonBin) + 
  labs(x = "ViolationCode", y = "Ticket Count", title = "Tickets Issued by top 3 Violation Code in 2015") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")


# Top 3 violation codes by season in 2015.
##########################################
# Autumn (September - November)
# Violation code 21     351,375 tickets
# Violation code 38     326,700 tickets
# Violation code 14     232,296 tickets

# Spring (March - May)
# Violation code 21     425,157 tickets
# Violation code 38     327,048 tickets
# Violation code 14     243,614 tickets

# Summer (June - August)
# Violation code 21     439,620 tickets
# Violation code 38     344,262 tickets
# Violation code 14     239,335 tickets

# Winter (December - February)
# Violation code 38     306,997 tickets
# Violation code 21     253,037 tickets
# Violation code 14     193,154 tickets

seasonBins2016 <- SparkR::sql("SELECT SeasonBin,
                              ViolationCode,
                              Count
                              FROM (SELECT SeasonBin,
                              ViolationCode,
                              Count,
                              dense_rank() over (partition by SeasonBin order by Count desc) Rnk
                              FROM (SELECT ViolationCode, COUNT (ViolationCode) AS Count,
                              CASE
                              WHEN IssueMonth >= 3 AND IssueMonth < 6 THEN 'Spring'
                              WHEN IssueMonth >= 6 AND IssueMonth < 9 THEN 'Summer'
                              WHEN IssueMonth >= 9 AND IssueMonth < 12 THEN 'Autumn'
                              WHEN IssueMonth >= 12 OR IssueMonth < 3 THEN 'Winter'
                              END AS SeasonBin
                              FROM data_2016_tbl
                              GROUP BY SeasonBin, ViolationCode))
                              WHERE Rnk <= 3
                              ORDER BY SeasonBin, Count DESC")
nrow(seasonBins2016)
head(seasonBins2016, 12)

df_seasonBins2016 <- data.frame(head(seasonBins2016,12))

# Plot the data.
ggplot(df_seasonBins2016, aes(x=as.factor(ViolationCode), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  facet_grid(~SeasonBin) + 
  labs(x = "ViolationCode", y = "Ticket Count", title = "Tickets Issued by top 3 Violation Code in 2016") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# Top 3 violation codes by season in 2016.
##########################################
# Autumn (September - November)
# Violation code 36     438,320 tickets
# Violation code 21     395,007 tickets
# Violation code 38     303,387 tickets

# Spring (March - May)
# Violation code 21     383,420 tickets
# Violation code 36     374,362 tickets
# Violation code 38     299,438 tickets

# Summer (June - August)
# Violation code 21     358,892 tickets
# Violation code 38     255,599 tickets
# Violation code 14     200,604 tickets

# Winter (December - February)
# Violation code 21     359,890 tickets
# Violation code 36     314,764 tickets
# Violation code 38     268,409 tickets

seasonBins2017 <- SparkR::sql("SELECT SeasonBin,
                              ViolationCode,
                              Count
                              FROM (SELECT SeasonBin,
                              ViolationCode,
                              Count,
                              dense_rank() over (partition by SeasonBin order by Count desc) Rnk
                              FROM (SELECT ViolationCode, COUNT (ViolationCode) AS Count,
                              CASE
                              WHEN IssueMonth >= 3 AND IssueMonth < 6 THEN 'Spring'
                              WHEN IssueMonth >= 6 AND IssueMonth < 9 THEN 'Summer'
                              WHEN IssueMonth >= 9 AND IssueMonth < 12 THEN 'Autumn'
                              WHEN IssueMonth >= 12 OR IssueMonth < 3 THEN 'Winter'
                              END AS SeasonBin
                              FROM data_2017_tbl
                              GROUP BY SeasonBin, ViolationCode))
                              WHERE Rnk <= 3
                              ORDER BY SeasonBin, Count DESC")
nrow(seasonBins2017)
head(seasonBins2017, 12)

df_seasonBins2017 <- data.frame(head(seasonBins2017,12))

# Plot the data.
ggplot(df_seasonBins2017, aes(x=as.factor(ViolationCode), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  facet_grid(~SeasonBin) + 
  labs(x = "ViolationCode", y = "Ticket Count", title = "Tickets Issued by top 3 Violation Code in 2017") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# Top 3 violation codes by season in 2017.
##########################################
# Autumn (September - November)
# Violation code 36     456,046 tickets
# Violation code 21     357,250 tickets
# Violation code 38     283,815 tickets

# Spring (March - May)
# Violation code 21     402,399 tickets
# Violation code 36     344,834 tickets
# Violation code 38     271,167 tickets

# Summer (June - August)
# Violation code 21     405,940 tickets
# Violation code 38     247,560 tickets
# Violation code 36     240,396 tickets

# Winter (December - February)
# Violation code 21     362,009 tickets
# Violation code 36     359,338 tickets
# Violation code 38     259,709 tickets

#####################################################################################

# 7) The fines collected from all the parking violation constitute a revenue source
# for the NYC police department. Lets take an example of estimating that for the
# three most commonly occurring codes.

# 7a) Find total occurrences of the three most common violation codes.

# This was already answered in aggregation task 1, however the numbers may now be
# slightly different (some rows with NULL values have since been deleted) so get up
# to date results for each year.
violationCodes2015 <- SparkR::sql("SELECT ViolationCode, Count(ViolationCode) AS Count
                                  FROM data_2015_tbl
                                  GROUP BY ViolationCode
                                  ORDER BY Count DESC")
head(violationCodes2015, 3)

df_violationCodes2015 <- data.frame(head(violationCodes2015,3))

# Plot the data.
ggplot(df_violationCodes2015, aes(x=reorder(as.factor(ViolationCode),-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "ViolationCode", y = "Ticket Count", title = "Tickets Issued by top 3 Violation Code in 2015") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# ViolationCode       Count                                                         
#       21        1,469,189
#       38        1,305,007
#       14          908,399

violationCodes2016 <- SparkR::sql("SELECT ViolationCode, Count(ViolationCode) AS Count
                                  FROM data_2016_tbl
                                  GROUP BY ViolationCode
                                  ORDER BY Count DESC")
head(violationCodes2016, 3)

df_violationCodes2016 <- data.frame(head(violationCodes2016,3))

# Plot the data.
ggplot(df_violationCodes2016, aes(x=reorder(as.factor(ViolationCode),-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "ViolationCode", y = "Ticket Count", title = "Tickets Issued by top 3 Violation Code in 2016") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# ViolationCode       Count                                                         
#       21        1,497,209
#       36        1,232,951
#       38        1,126,833

violationCodes2017 <- SparkR::sql("SELECT ViolationCode, Count(ViolationCode) AS Count
                                  FROM data_2017_tbl
                                  GROUP BY ViolationCode
                                  ORDER BY Count DESC")
head(violationCodes2017, 3)
# ViolationCode       Count                                                         
#       21        1,500,341
#       36        1,345,237
#       38        1,050,415

df_violationCodes2017 <- data.frame(head(violationCodes2017,3))

# Plot the data.
ggplot(df_violationCodes2017, aes(x=reorder(as.factor(ViolationCode),-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "ViolationCode", y = "Ticket Count", title = "Tickets Issued by top 3 Violation Code in 2017") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# Comparative Analysis for all the years.
df_violationCodes2015$Year <- c(2015,2015,2015)
df_violationCodes2016$Year <- c(2016,2016,2016)
df_violationCodes2017$Year <- c(2017,2017,2017)

df_violationCodescombined <- rbind(df_violationCodes2015,df_violationCodes2016,df_violationCodes2017)

# Plot the data.
ggplot(df_violationCodescombined, aes(x=reorder(as.factor(ViolationCode),-Count), y=Count))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') + facet_wrap(~Year) +
  labs(x = "ViolationCode", y = "Ticket Count", title = "Tickets Issued by top 3 Violation Code,Year") +
  geom_text(aes(label=Count),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

#####################################################################################

# 7b) Then, visit the website:
# http://www1.nyc.gov/site/finance/vehicles/services-violation-codes.page
# It lists the fines associated with different violation codes. They are divided into
# two categories, one for the highest-density locations of the city, the other for
# the rest of the city. For simplicity, take an average of the two.

# The codes we are interested in, across all three years are:

# Violation Code      Higher      Lower      Average
# 14                  $115        $115        $115
# 21                  $65         $45         $55
# 36                  $50         $50         $50
# 38                  $65         $35         $50

#####################################################################################

# 7c) Using this information, find the total amount collected for the three violation
# codes with maximum tickets. State the code which has the highest total collection.

violationCodes2015 <- SparkR::sql("SELECT ViolationCode,Count,FineAmount,Count*FineAmount as Total_Fine from 
                                  (SELECT ViolationCode, COUNT (ViolationCode) AS Count,
                                  CASE
                                  WHEN ViolationCode = 14 THEN 115
                                  WHEN ViolationCode = 21 THEN 55
                                  WHEN ViolationCode = 38 THEN 50
                                  END AS FineAmount
                                  FROM data_2015_tbl WHERE ViolationCode in(14,21,38)
                                  GROUP BY ViolationCode,FineAmount) Order by ViolationCode asc")
head(violationCodes2015, 100)

df_violationCodes2015 <- data.frame(head(violationCodes2015,3))

# Plot the data.
ggplot(df_violationCodes2015, aes(x=reorder(as.factor(ViolationCode),-Total_Fine), y=Total_Fine))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "ViolationCode", y = "Total_Fine", title = "Total_Fine collected by top 3 Violation Code in 2015") +
  geom_text(aes(label=Total_Fine),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# 2015 Total collections
# ViolationCode      Count          Fine Amount     Total Fine
#       14          908,399         $115            $104,465,885
#       21        1,469,189          $55             $80,805,395
#       38        1,305,007          $50             $65,250,350

# Code 14 has the highest total collection out of the three most common codes in 2015.

violationCodes2016 <- SparkR::sql("SELECT ViolationCode,Count,FineAmount,Count*FineAmount as Total_Fine from 
                                  (SELECT ViolationCode, COUNT (ViolationCode) AS Count,
                                  CASE
                                  WHEN ViolationCode = 21 THEN 55
                                  WHEN ViolationCode = 36 THEN 50
                                  WHEN ViolationCode = 38 THEN 50
                                  END AS FineAmount
                                  FROM data_2016_tbl WHERE ViolationCode in(21,36,38)
                                  GROUP BY ViolationCode,FineAmount) Order by ViolationCode asc")
head(violationCodes2016, 100)

df_violationCodes2016 <- data.frame(head(violationCodes2016,3))

# Plot the data.
ggplot(df_violationCodes2016, aes(x=reorder(as.factor(ViolationCode),-Total_Fine), y=Total_Fine))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "ViolationCode", y = "Total_Fine", title = "Total_Fine collected by top 3 Violation Code in 2016") +
  geom_text(aes(label=Total_Fine),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")


# 2016 total collections

# ViolationCode      Count          Fine Amount     Total Fine                                                        
#       21        1,497,209         $55             $82,346,495
#       36        1,232,951         $50             $61,647,550
#       38        1,126,833         $50             $56,341,650

# Code 21 has the highest total collection out of the three most common codes in 2016.

violationCodes2017 <- SparkR::sql("SELECT ViolationCode,Count,FineAmount,Count*FineAmount as Total_Fine from 
                                  (SELECT ViolationCode, COUNT (ViolationCode) AS Count,
                                  CASE
                                  WHEN ViolationCode = 21 THEN 55
                                  WHEN ViolationCode = 36 THEN 50
                                  WHEN ViolationCode = 38 THEN 50
                                  END AS FineAmount
                                  FROM data_2017_tbl WHERE ViolationCode in(21,36,38)
                                  GROUP BY ViolationCode,FineAmount) Order by ViolationCode asc")
head(violationCodes2017, 100)

df_violationCodes2017 <- data.frame(head(violationCodes2017,3))

# Plot the data.
ggplot(df_violationCodes2017, aes(x=reorder(as.factor(ViolationCode),-Total_Fine), y=Total_Fine))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') +
  labs(x = "ViolationCode", y = "Total_Fine", title = "Total_Fine collected by top 3 Violation Code in 2017") +
  geom_text(aes(label=Total_Fine),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

# 2017 total collections

# ViolationCode      Count          Fine Amount     Total Fine                                                        
#       21        1,500,341         $55             $82,518,755
#       36        1,345,237         $50             $67,261,850
#       38        1,050,415         $50             $52,520,750

# Code 21 has the highest total collection out of the three most common codes in 2017.

# Comparative Analysis for all the years.
df_violationCodes2015$Year <- c(2015,2015,2015)
df_violationCodes2016$Year <- c(2016,2016,2016)
df_violationCodes2017$Year <- c(2017,2017,2017)

df_violationCodescombined <- rbind(df_violationCodes2015,df_violationCodes2016,df_violationCodes2017)

# Plot the data.
ggplot(df_violationCodescombined, aes(x=reorder(as.factor(ViolationCode),-Total_Fine), y=Total_Fine))+
  geom_bar(stat = "identity", position = "dodge",fill='#1567b6') + facet_wrap(~Year) +
  labs(x = "ViolationCode", y = "Total_Fine", title = "Total_Fine collected by top 3 Violation Code,Year") +
  geom_text(aes(label=Total_Fine),vjust=-0.3) +
  theme(axis.text.x = element_text(vjust=0.5, hjust=1),legend.position="none")

#####################################################################################

# 7d) What can you intuitively infer from these findings?

#From above information, Out of all Violation Code for the year 2015, Violation Code 14 has the highest total amount collected at 104.46 million 
#even though it had the lowest ticket count (908,399) out of the top-3 Violation Codes (14, 21 and 38). 
#This is due to the high average fine amount of $115 per ticket with Violation Code 14. 
#But Violations code 14 doesn't occur in 2016 and 2017.
#Violation Code 21 has the highest total fine amount collected at $80.80 million in total fine amount 
#for number of tickets (1,469,189) in 2015.
#In the year 2016 and 2017 Violation Code 21 brought the highest total fine amount 
#at $82.34 million and $82.52 million respectively. 
#Violation Code 21 is highest fine amount collected over all in all the years. 
#Violation Code 21 and 38 are common across all the years.


#####################################################################################
# End the spark session when finished running the code.
sparkR.stop()
